package base;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.sikuli.script.ScreenImage;
import org.sikuli.script.SikuliException;

import pages.InsuranceClaim;


public class WdMethods extends WdEventImpl{	
	public static int dbRowCount;

	public WebElement locateElement(String how, String using) {
		WebElement ele = null;
		switch(how) {
		case("id"):
			ele = getEventDriver().findElement(By.id(using));
		break;
		case("name"):
			ele = getEventDriver().findElement(By.name(using));
		break;
		case("linkText"):
			ele = getEventDriver().findElement(By.linkText(using));
		break;
		case("xpath"):
			ele = getEventDriver().findElement(By.xpath(using));
		break;
		case("partialLinkText"):
			ele = getEventDriver().findElement(By.partialLinkText(using));
		break;
		case("cssSelector"):
			ele = getEventDriver().findElement(By.cssSelector(using));
		break;
		case("tagName"):
			ele = getEventDriver().findElement(By.tagName(using));
		break;
		case("className"):
			ele = getEventDriver().findElement(By.className(using));
		break;
		default:
			reportStep("The given locator "+how+" is not correct", "FAIL");
			break;
		}
		return ele;			
	}

	public void clear(WebElement ele) {
		ele.clear();
	}

	public void type(WebElement ele, String data) {
		
		ele.clear();
		pause(2);
		ele.sendKeys(data);

	}
	
	public void typeAndTab(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data, Keys.TAB);
	}

	public void typeAndChoose(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data);
		pause(5);

		ele.sendKeys(Keys.DOWN, Keys.ENTER);
	}

	public void click(WebElement ele) {
		//System.out.println(driver);
		ele.click();
	}

	public void selectUsingText(WebElement ele, String text) {
		select(ele, "text", text);

	}
	public void scrollandselectUsingText(WebElement ele, String text) {
		scrollandselect(ele, "text", text);

	}

	public void selectUsingValue(WebElement ele, String value) {
		select(ele, "value", value);

	}

	public void selectUsingIndex(WebElement ele, int index) {
		new Select(ele).selectByIndex(index);
	}

	private void scrollandselect(WebElement ele, String type, String textOrValue) {
		System.out.println(ele);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].scrollIntoView(true);",ele); 
		if(type.equalsIgnoreCase("text"))
		{
			try {
				ele.click();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
			//new Select(ele).selectByVisibleText(textOrValue);
		}
		else
		{	
			ele.click();
		}

		/*if(ele.getTagName().equals("select")) {
			if(type.equalsIgnoreCase("text"))


				new Select(ele).selectByVisibleText(textOrValue);
			else
				new Select(ele).selectByValue(textOrValue);
		}else {
			ele.click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			//locateElement("xpath", "//li[text()='"+textOrValue+"']").click();			
		}*/
	}
	private void select(WebElement ele, String type, String textOrValue) {
		if(ele.getTagName().equals("select")) {
			if(type.equalsIgnoreCase("text"))
				new Select(ele).selectByVisibleText(textOrValue);
			else
				new Select(ele).selectByValue(textOrValue);
		}else {
			ele.click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			//locateElement("xpath", "//li[text()='"+textOrValue+"']").click();			
		}
	}

	public String getText(WebElement ele){
		return ele.getText();
	}	

	public String getAttributeText(WebElement ele, String value){
		return ele.getAttribute(value);
	}

	/*public boolean verifyText(WebElement ele, String text) { 
		return ele.getText().equals(text);

		}*/

	public void verifyText(WebElement ele,String text) {
		if(ele.getText().equals(text)) {
			System.out.println(ele.getText());
			reportStep("The given text "+text+" is matched-Validation Pass", "PASS");
		}else {
			reportStep("The given text "+text+" is not matched-Validation failed", "WARNING");
		}
	}


	public boolean verifyPartialText(WebElement ele, String text) {
		return ele.getText().contains(text);
	}	

	public boolean verifyTitle(String title) {
		return getEventDriver().getTitle().equalsIgnoreCase(title);
	}


	public void switchToFrame(WebElement ele) {
		getEventDriver().switchTo().frame(ele);
	}

	public void switchToFrame(int index) {
		getEventDriver().switchTo().frame(index);
	}

	public void acceptAlert() {
		getEventDriver().switchTo().alert().accept();
	}

	public void dismissAlert() {
		getEventDriver().switchTo().alert().dismiss();
	}

	public void sendTextAlert(String txt) {
		getEventDriver().switchTo().alert().sendKeys(txt);
	}

	public void Refresh() {
		getEventDriver().navigate().refresh();
	}

	public String getTextAlert() {
		return getEventDriver().switchTo().alert().getText();
	}	

	public void switchWindow(int index) {
		List<String> lstWindows = new ArrayList<>();
		lstWindows.addAll(getEventDriver().getWindowHandles());
		getEventDriver().switchTo().window(lstWindows.get(index));
	}


	public void mouseOverOnElement(WebElement ele) {
		new Actions(getEventDriver()).pause(2000).moveToElement(ele).click().build().perform();
		pause(1);
	}

	public void pause(long seconds) {
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void check(WebElement ele) {
		if(!ele.isSelected()) {
			ele.click();
		}
	}





	public void verifyExists(WebElement ele) {
		if(ele.isDisplayed()) {
			reportStep("The element "+ele+" is visible", "PASS");
		}else {
			reportStep("The element "+ele+" is not visible", "WARNING");
		}
	}



	public void VerifyElementIsEnabled(WebElement ele)
	{
		if(ele.isEnabled())
		{

			reportStep("The element "+ele+" is Enabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Disabled", "WARNING");
		}
	}


	public void VerifyElementIsDisabled(WebElement ele)
	{
		if(!ele.isEnabled())
		{

			reportStep("The element "+ele+" is Disabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Enabled", "WARNING");
		}
	}


	public void typeandEnter(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data,Keys.ENTER);

	}

	public int locateWebTableColumn(String columnName) {
		List<WebElement> ele = null;
		switch("xpath") {

		case("xpath"):
			ele = getEventDriver().findElements(By.xpath("//*[text()='"+columnName+"']/parent::th/preceding-sibling::*"));
		System.out.println(ele.size());

		break;

		default:
			reportStep("The given locator xpath is not correct", "FAIL");
			break;
		}
		return ele.size()+1 ;			
	}

	public WebElement locateWebTableElement(String columnName,int rowIndex) {
		WebElement ele = null;
		int columnIndex=locateWebTableColumn(columnName);
		switch("xpath") {

		case("xpath"):
			ele = getEventDriver().findElement(By.xpath("//*[text()='"+columnName+"']/parent::th/following::tr["+rowIndex+"]/td["+columnIndex+"]"));
		System.out.println(ele);

		break;

		default:
			reportStep("The given locator xpath is not correct", "FAIL");
			break;
		}
		return ele;	

	}

	public void Uncheck(WebElement ele) {
		if(ele.isSelected()) {
			ele.click();
		}
	}	




	public void BundleQuantityEqualsToStock(WebElement eleBundleStockQuantity,WebElement eleBundleQuantity ) 

	{


		String bundlestockquanity = getText(eleBundleStockQuantity);
		int bundlestock=Integer.parseInt(bundlestockquanity);
		int enterBundlequanity=bundlestock;

		if(bundlestock>=0)
		{
			String bundlequanity = Integer.toString(enterBundlequanity);
			type(eleBundleQuantity, bundlequanity);
		}

	}


	public void BundleQuantityGreaterThanStock(WebElement eleBundleStockQuantity,WebElement eleBundleQuantity)
	{

		String bundlestockquanity = getText(eleBundleStockQuantity);
		int bundlestock=Integer.parseInt(bundlestockquanity);
		int enterBundlequanitygreaterthanBundleStock=bundlestock+1;

		if(bundlestock>=1)
		{
			String bundlequanity = Integer.toString(enterBundlequanitygreaterthanBundleStock);
			type(eleBundleQuantity, bundlequanity);
		}
	}



	public void BundleQuantityLesserThanStock(WebElement eleBundleStockQuantity,WebElement eleBundleQuantity)
	{

		String bundlestockquanity = getText(eleBundleStockQuantity);
		int bundlestock=Integer.parseInt(bundlestockquanity);
		int enterBundlequanity=bundlestock-1;
		int enterNonzeroBundlequantity=bundlestock;

		if(bundlestock>=1 && enterBundlequanity!=0)
		{
			String bundlequanity = Integer.toString(enterBundlequanity);
			type(eleBundleQuantity, bundlequanity);
		}

		else
		{ 
			String NonzeroBundleQuanity = Integer.toString(enterNonzeroBundlequantity);
			type(eleBundleQuantity, NonzeroBundleQuanity);
		}

	}




	public void selectDateFromKendo(String ReceiptDate)
	
	{
		WebElement kendodtp = getDriver().findElement(By.cssSelector(".k-icon.k-i-calendar"));
		kendodtp.click();
		pause(2);

		/*wait.until(ExpectedConditions.presenceOfElementLocated(By
				.className("k-content")));*/
		WebElement table = getDriver().findElement(By.className("k-content"));

		System.out.println("Kendo Calendar");
		List<WebElement> tableRows = table.findElements(By.xpath("//tr"));
		for (WebElement row : tableRows) {
			List<WebElement> cells = row.findElements(By.xpath("//td"));

			for (WebElement cell : cells) {
				if (cell.getText().equals(ReceiptDate)) {
					getDriver().findElement(By.linkText(ReceiptDate)).click();
				}
			}
		}
		pause(2);
	}

	public void datePicker(WebElement ele1,WebElement ele2,WebElement ele3, String i, String monthvalue, String yearvalue, String rowsIndex, String colIndex) {
		//ele1.click();
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",ele1); 

		/*selectUsingValue(locateElement("xpath", "(//select[@class='monthselect'])[1]"), monthvalue);

		selectUsingValue(locateElement("xpath", "(//select[@class='yearselect'])[1]"), yearvalue);*/

		selectUsingText((ele2), monthvalue);

		selectUsingText((ele3), yearvalue);


		pause(3);
		int i1=Integer.parseInt(i);
		WebElement datePicker=getDriver().findElement(By.xpath("(//div[@class='calendar-table']/table/thead/tr/following::tbody)["+i+"]"));
		//WebElement datePicker=getDriver().findElement(By.xpath("//div[@class='"+className+"']/table/thead/tr/following::tbody"));
		List<WebElement> allRows = datePicker.findElements(By.tagName("tr"));
		int row1 = Integer.parseInt(rowsIndex);
		int col1 = Integer.parseInt(colIndex);
		WebElement row = allRows.get(row1);
		List<WebElement> listRowForColumn = row.findElements(By.tagName("td"));
		listRowForColumn.get(col1).click();


	}

	public void selectDate1(WebElement dateField, String fieldText, String month, String year, String date) {

		click(dateField);
		WebElement eleMonth = locateElement("xpath", "//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='monthselect']");
		selectUsingText(eleMonth, month);
		WebElement eleYear = locateElement("xpath", "//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']");
		selectUsingText(eleYear,year );
		WebElement eleDate = locateElement("xpath", "//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']/following::td[text()='"+date+"']");
		click(eleDate);

	}

	public void selectDate2(WebElement dateField, String fieldText, String month, String year, String date) {

		click(dateField);
		WebElement eleMonth = locateElement("xpath", "(//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='monthselect'])[1]");
		selectUsingText(eleMonth, month);
		WebElement eleYear = locateElement("xpath", "(//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect'])[1]");
		selectUsingText(eleYear,year );
		WebElement eleDate = locateElement("xpath", "(//label[text()='"+fieldText+"']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']/following::td[text()='"+date+"'])[1]");
		click(eleDate);

	}

	public void selectDate3(WebElement dateField, String fieldText, String month, String year, String date) {

		click(dateField);
		WebElement eleMonth = locateElement("xpath", "(//label[contains(text(),'"+fieldText+"')]/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='monthselect'])[1]");
		selectUsingText(eleMonth, month);
		WebElement eleYear = locateElement("xpath", "(//label[contains(text(),'"+fieldText+"')]/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect'])[1]");
		selectUsingText(eleYear,year );
		WebElement eleDate = locateElement("xpath", "(//label[contains(text(),'"+fieldText+"')]/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']/following::td[text()='"+date+"'])[1]");
		click(eleDate);

	}



	/*public void datePicker2(WebElement ele1) {
		//ele1.click();
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",ele1); 

		WebElement datePicker=getDriver().findElement(By.xpath()

		pause(3);
		int i1=Integer.parseInt(ii);
		WebElement datePicker=getDriver().findElement(By.xpath("(//div[@class='calendar-table']/table/thead/tr/following::tbody)["+ii+"]"));
		//WebElement datePicker=getDriver().findElement(By.xpath("//div[@class='"+className+"']/table/thead/tr/following::tbody"));
		List<WebElement> allRows = datePicker.findElements(By.tagName("tr"));
		int row1 = Integer.parseInt(rowsIndex1);
		int col1 = Integer.parseInt(colIndex1);
		WebElement row = allRows.get(row1);
		List<WebElement> listRowForColumn = row.findElements(By.tagName("td"));
		listRowForColumn.get(col1).click();


	}
	 */



	public void sikuli (String path) throws SikuliException  {
		Screen screen1 = new Screen();
		Pattern image1 = new Pattern(path);
		screen1.click(image1);
	}

	public static Object[][] getDataFromDb(String sql){



		// JDBC driver name and database URL
		final String JDBC_DRIVER = PreAndPost.config.getProperty("DB_Pkg");  
		final String DB_URL = PreAndPost.config.getProperty("DB_Url");

		//  Database credentials
		final String USER = PreAndPost.config.getProperty("DB_User");
		final String PASS = PreAndPost.config.getProperty("DB_Pwd");

		Connection conn = null;
		Statement stmt = null;

		Object[][] data = null;

		try{

			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			//STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL,USER,PASS);

			//STEP 4: Execute a query
			stmt = conn.createStatement();

			String count = "Select count(*) from ("+sql+") AS T";
			ResultSet rs = stmt.executeQuery(count);
			rs.next();
			int rowCount = rs.getInt(1);

			// Now run the query
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd=rs.getMetaData();


			// get the column count
			int columnCount = rsmd.getColumnCount();

			data = new Object[rowCount][columnCount]; // assign to the data provider array
			int i = 0;

			//STEP 5: Extract data from result set
			while(rs.next()){

				for (int j = 1; j <= columnCount; j++) {
					switch (rsmd.getColumnType(j)) {
					case Types.VARCHAR:
						data[i][j-1] = rs.getString(j);
						break;
					case Types.NULL:
						data[i][j-1] = "";
						break;
					case Types.CHAR:
						data[i][j-1] = rs.getString(j);
						break;
					case Types.TIMESTAMP:
						data[i][j-1] = rs.getDate(j);
						break;
					case Types.DOUBLE:
						data[i][j-1] = rs.getDouble(j);
						break;
					case Types.INTEGER:
						data[i][j-1] = rs.getInt(j);
						break;
					case Types.SMALLINT:
						data[i][j-1] = rs.getInt(j);
						break;

					}
				}
				i++;
			}
			//STEP 6: Clean-up environment
			rs.close();
			stmt.close();
			conn.close();

		}catch(SQLException se){

			//Handle errors for JDBC
			se.printStackTrace();

		}catch(Exception e){

			//Handle errors for Class.forName
			e.printStackTrace();

		}finally{

			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se){
				se.printStackTrace();
			}

			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return data;


	}


	public void FileUpload(String filePath)
	{
		//(//button[contains(@title,'Click to Upload')])["+i+"]
		getDriver().findElement(By.xpath("(//input[@type='file'])[9]")).sendKeys(filePath);


	}



}
















