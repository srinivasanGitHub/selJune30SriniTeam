package base;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import reporter.ReportImpl;
import reporter.Reporter;

public class WdEventImpl extends ReportImpl implements WebDriverEventListener {

	protected WebDriver driver;
	protected EventFiringWebDriver e_driver;
	protected WebDriverWait wait;
	protected static final ThreadLocal<WdEventImpl> driverThreadLocal = new ThreadLocal<WdEventImpl>();
	protected boolean bReport = true;
	public static Properties config;

	public void setDriver(WdEventImpl webdrvrEvntImpl) {
		driverThreadLocal.set(webdrvrEvntImpl);
	}

	public WebDriver getDriver() {
		return driverThreadLocal.get().driver;
	}

	public EventFiringWebDriver getEventDriver() {
		return driverThreadLocal.get().e_driver;
	}

	public void beforeAlertAccept(WebDriver driver) {


	}

	public void afterAlertAccept(WebDriver driver) {


	}

	public void afterAlertDismiss(WebDriver driver) {


	}

	public void beforeAlertDismiss(WebDriver driver) {


	}

	public void beforeNavigateTo(String url, WebDriver driver) {


	}

	public void afterNavigateTo(String url, WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait(driver, 10);
		reportStep("The browser "+driver.toString().split(":")[1].trim().split(" ")[0].trim()+" is launched with Url "+url, "PASS");		
	}

	public void beforeNavigateBack(WebDriver driver) {


	}

	public void afterNavigateBack(WebDriver driver) {


	}

	public void beforeNavigateForward(WebDriver driver) {


	}

	public void afterNavigateForward(WebDriver driver) {


	}

	public void beforeNavigateRefresh(WebDriver driver) {


	}

	public void afterNavigateRefresh(WebDriver driver) {


	}

	public void beforeFindBy(By by, WebElement element, WebDriver driver) {


	}

	public void afterFindBy(By by, WebElement element, WebDriver driver) {


	}

	public void beforeClickOn(WebElement element, WebDriver driver) {		

		boolean bFound = false;
		try {
			driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
			bReport=false;
			//e_driver.findElement(By.xpath("//span[text()='Insurance Claim']"));
			bFound = true;
		}catch (Exception e) {

		}
		bReport = true;
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		if(bFound) {
			try {
			//	wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//span[text()='Insurance Claim']")));
			} catch (Exception e) {
			
			}
		}
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			wait.until(ExpectedConditions.elementToBeClickable(element));
		} catch (Exception e) {
			
		}		
	}

	public void afterClickOn(WebElement element, WebDriver driver) {
		String eleText = element.toString().split("->")[1].replaceAll("]", "");
		if(isAlertExist())
			reportStep("The element "+eleText+" is clicked","INFO");		
		else
			reportStep("The element "+eleText+" is clicked","PASS");		
	}

	public void beforeChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
		wait.until(ExpectedConditions.elementToBeClickable(element));
		System.out.println("I am clickable "+element);
		//element.clear();

	}

	public void afterChangeValueOf(WebElement element, WebDriver driver, CharSequence[] keysToSend) {
		String eleText = element.toString().split("->")[1].replaceAll("]", "");
		if(keysToSend != null)
			reportStep("The element "+eleText+" is entered with text :"+keysToSend[0],"PASS");		

	}

	public void beforeScript(String script, WebDriver driver) {


	}

	public void afterScript(String script, WebDriver driver) {


	}

	public void onException(Throwable throwable, WebDriver driver) {
		if(throwable instanceof NoSuchElementException && bReport) {
			reportStep("The element :"+throwable.getMessage().split("Element info: ")[1]+" not found", "FAIL");
			throw new RuntimeException();
		}

		System.out.println("The error is"+ throwable.getMessage());
	}

	public boolean isAlertExist() {
		boolean bAlertExists =  false;
		try {
			driver.switchTo().alert();
			bAlertExists = true;
		} catch (Exception e) {

		}
		return bAlertExists;
	}

	@Override
	public long takeSnap() {
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE) , new File("./reports/images/"+number+".jpg"));
		} catch (WebDriverException e) {
			reportStep("The browser has been closed.", "FAIL");
		} catch (IOException e) {
			reportStep("The snapshot could not be taken", "WARN");
		}
		return number;
	}

	public EventFiringWebDriver init(WebDriver driver) {
		e_driver = new EventFiringWebDriver(driver);
		e_driver.register(this);
		return e_driver;
	}

	public static void unset() { 
		driverThreadLocal.remove(); 
	}

	public <X> void afterGetScreenshotAs(OutputType<X> arg0, X arg1) {
		// TODO Auto-generated method stub

	}

	public void afterSwitchToWindow(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}

	public <X> void beforeGetScreenshotAs(OutputType<X> arg0) {
		// TODO Auto-generated method stub

	}

	public void beforeSwitchToWindow(String arg0, WebDriver arg1) {
		// TODO Auto-generated method stub

	}


}
