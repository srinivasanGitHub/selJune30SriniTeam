package testCases.Login;


import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_LoginValidCredentials   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_LoginValidCredentials";
		testDescription="TC001_LoginValidCredentials";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC001_Login";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd) throws SikuliException {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.InvalidCredentials();





	}

}
