package testCases.Login;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC007_ValidUserNameEmptyPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC008_InvalidValidUserNameEmptyPassword";
		testDescription="TC008_InvalidValidUserNameEmptyPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC007_Login";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
