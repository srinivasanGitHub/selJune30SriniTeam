package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_Miscellaneous_Claim_Creation_REO_Option_Select_No extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous_Claim_Creation_REO_Option_Select_No";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Miscellaneous_Claim_Creation_FIRNum_REO_Option_No";
		//dataSheetName="TC002_test";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String JobCode,String month,String year,String className,String rows, String col, String PolicyNumber,String dataPolicyType
			,String dataInsuranceCompanyDetail,String dataEmployeeNumber,String dataEmployeeName,String dataEmployeeDepartment,String dataCauseOfLoss,String OccuranceDetails,String TheftBurglary,String FIRNumber,String monthFIR, String yearFIR,String className2,String rowsFIR,String co1FIR,
			String dataPropertyLostDamaged1,String dataPropertyLostDamaged2,String dataOtherPropertyLoss ,String dataTypeOfLoss,String dataIndependentCompany,String dataPolicyValidFrom
			,String dataPolicyValidTo, String dataSumInsured,String dataExcessAmount,String dataEstimateValue, String PlantAndMachineryItem ,String dataisRepairedEstimateObtained,String dataPSNOGrid,String dataPSNOGrid1 )
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.typeAndEnterJobCode(JobCode)
		.clickandSelectDateOfLoss(month,year,className,rows, col)
		.typeAndChoosePolicyNumber(PolicyNumber)
		.verifyExactTextPolicyType(dataPolicyType)
		.verifyExactTextInsuranceCompanyDetail(dataInsuranceCompanyDetail)
		.typeAndChooseEmployeeNumber(dataEmployeeNumber)
		.verifyExactTextEmployeeName(dataEmployeeName)
		.verifyExactTextEmployeeDepartment(dataEmployeeDepartment)
		.clickCauseOfLoss()
		.selectUsingTextCauseOfLoss(dataCauseOfLoss)
		.typeOccuranceDetails(OccuranceDetails)
		.clickTheftBurglary()
		.selectUsingTextTheftBurglary(TheftBurglary)
		.typeFIRNumber(FIRNumber)
		.clickFIRDate(monthFIR, yearFIR,className2, rowsFIR, co1FIR)
		//.selectUsingTextOccurenceEnroot(dataOccurenceEnroot)
		.clickPropertyLostDamaged()
		.selectUsingTextPropertyLostDamaged(dataPropertyLostDamaged1,dataPropertyLostDamaged2)
		.typeOtherPropertyLoss(dataOtherPropertyLoss)
		.clickTypeOfLoss()
		.selectUsingTextTypeOfLoss(dataTypeOfLoss)
		.verifyExactTextIndependentCompany(dataIndependentCompany)
		.verifyExactTextPolicyValidFrom(dataPolicyValidFrom)
		.verifyExactTextPolicyValidTo(dataPolicyValidTo)
		.verifyExactTextSumInsured(dataSumInsured)
		.typeExcessAmount(dataExcessAmount)
		.typeEstimateValue(dataEstimateValue)
		.clickPlantAndMachineryItem()
		.selectUsingTextPlantAndMachineryItem(PlantAndMachineryItem)
		.SelectRepairedEstimateObtained()
		.selectUsingTextRepairedEstimateObtained(dataisRepairedEstimateObtained)
		.clickAddNewRecordGrid()
		.typePSNOGrid(dataPSNOGrid)
		//.verifyExactTextCNGrid(dataCNGrid)
		/*.verifyExactMobileNo(dataMN)
		.verifyExactEmailNo(dataEMN)*/
		.clickAddNewRecordGrid()
		.typePSNOGrid(dataPSNOGrid1)
		
		.clickSubmit()
		.getdialogMsg()
		.closeDialogMsg();

}

}
