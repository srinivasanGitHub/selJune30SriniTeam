package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_Miscellaneous_Claim_Creation_JobCode_End_WithWhiteSpace extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous Policy Claim_Creation_JobCode_End_WithWhiteSpace ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Miscellaneous_Claim_Creation _End_With_White_Space";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String JobCode)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.typeAndEnterJobCode(JobCode)
		.clickSubmit()
		.getdialogMsg()
		.closeDialogMsg();





	}

}
