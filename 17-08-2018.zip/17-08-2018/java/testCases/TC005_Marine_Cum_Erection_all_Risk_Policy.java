package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.interactions.Pause;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_Marine_Cum_Erection_all_Risk_Policy extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Marine_Cum_Erection_all_Risk_Policy ";
		testDescription="Marine_Cum_Erection_all_Risk_Policy";
		category="Functionlity";
		dataSource="Excel";
	dataSheetName="TC005_Marine_Cum_erection_Policy";
		//dataSheetName="TC005_Marine_Cum_erection_Policy - Copy";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String JobCode,String month,String year,String className,String rows, String col, String PolicyNumber,
			String dataCauseOfLoss,String OccuranceDetails,String TheftBurglary,String FIRNumber
			,String monthFIR, String yearFIR,String className2,String rowsFIR,String co1FIR,String ModeOfTransport,String DeliveryProperty,String dataOccurenceEnroot,String monthR, String yearR,String classNameR,String rowsR,String colR,String monthU,String yearU,String classnameU,String rowsU,String colU,String dataInvoiceValue,String dataPropertyLostDamaged1,String dataPropertyLostDamaged2,String dataOtherPropertyLoss ,
			String dataExcessAmount,String dataEstimateValue,String dataPLD,String dataDeriverSign,String dataCOCDU,String PlantAndMachineryItem,String dataVehicleRegNo,String dataVehicleLRNo,String monthLR,String yearLR,String classnameLR, String rowsLR, String colLR,String monthTransportedFrom,String yearTransportedFrom,String classnameTransportedFrom,String rowsTransportedFrom,String colTransportedFrom,
			String monthTransportedTo,String yearTransportedTo,String classnameTransportedTo,String rowsTransportedTo,String colTransportedTo,
			String dataTransporterName,String dataTransporterAddress,String dataAddressForInspection,String dataPSNOGrid,String dataPSNOGrid1)
	
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.typeAndEnterJobCode(JobCode)
		.clickandSelectDateOfLoss(month,year,className,rows, col)
		.typeAndChoosePolicyNumber(PolicyNumber)
		
		//.typeAndChooseEmployeeNumber(dataEmployeeNumber)
		//.verifyExactTextEmployeeName(dataEmployeeName)
	//	.verifyExactTextEmployeeDepartment(dataEmployeeDepartment)
		.clickCauseOfLoss()
		.selectUsingTextCauseOfLoss(dataCauseOfLoss)
		.typeOccuranceDetails(OccuranceDetails)
		.clickTheftBurglary()
		.selectUsingTextTheftBurglary(TheftBurglary)
		.typeFIRNumber(FIRNumber)
		.clickFIRDate(monthFIR, yearFIR,className2, rowsFIR, co1FIR)
		.clickModeOfTransport()
		.selectUsingTextModeOfTransport(ModeOfTransport)
		.clickDeliveryProperty()
		.selectUsingTexteleDeliveryProperty(DeliveryProperty)
		.selectUsingTextOccurenceEnroot(dataOccurenceEnroot)
		.clickandSelectDateOfReceiptOfConsignmentAtSite(monthR, yearR, classNameR, rowsR, colR)
		.clickandSelectUnpacked(monthU, yearU, classnameU, rowsU, colU)
		.typeAndChooseInvoiceValue(dataInvoiceValue)
		.clickPropertyLostDamaged()
		.selectUsingTextPropertyLostDamaged(dataPropertyLostDamaged1,dataPropertyLostDamaged2)
		.typeOtherPropertyLoss(dataOtherPropertyLoss)
		//.clickTypeOfLoss()
		//.selectUsingTextTypeOfLoss(dataTypeOfLoss)
		.typeExcessAmount(dataExcessAmount)
		.typeEstimateValue(dataEstimateValue)
		.typePLD(dataPLD)
	//	.typeCargoDesc(dataCargoDesc)
		.selectUsingValueDriverSignObtained(dataDeriverSign)
		.typeeleConditionOfConsignmentDuringUnpacking(dataCOCDU)
		.clickPlantAndMachineryItem()
		
		.selectUsingTextPlantAndMachineryItem(PlantAndMachineryItem)
		//.clickandSelectSendingLetterDate(monthSLetter, SLetter)
	
		/*.clicksendingletter()
		.selectUsingTextsendingletter(sendingletter)*/
		
		
		.typeVehicleRegNo(dataVehicleRegNo)
		.typeVehicleLRNo(dataVehicleLRNo)
		.clickandSelectLRDate(monthLR, yearLR)
	//	.clickandSelectTransportedFrom(monthTransportedFrom, yearTransportedFrom)
		//.clickandSelectTransportedTo(monthTransportedTo, yearTransportedTo, classnameTransportedTo, rowsTransportedTo, colTransportedTo)
		.typeTransporterName(dataTransporterName)
		.typeTransporterAddress(dataTransporterAddress)
		.typeAddressForInspection(dataAddressForInspection)
		
		//.typeisRepairedEstimateObtained(dataisRepairedEstimateObtained)
		.clickAddNewRecordGrid()
		.typePSNOGrid(dataPSNOGrid)

		.clickAddNewRecordGrid()
		.typePSNOGrid(dataPSNOGrid1)
		
		.clickAssetAddNewRecordGrid()
		.clickAssertDamageCreate()
		
		.clickSubmit();





	}

}
