package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_Miscellaneous_Claim_Creation_without_anyFields extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous_Claim_Creation - Without_AnyField_Submit ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Miscellaneous_Claim_Creation - Without_AnyField_Submit";
		//dataSheetName="TC002_test";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.clickSubmit()
		.getdialogMsg()
		.closeDialogMsg();





	}

}
