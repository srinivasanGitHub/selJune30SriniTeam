package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_Miscellaneous_Claim_Creation_JobCode_Start_WithSpecial_Character extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous_Claim_Creation_JobCode_End_WithWhiteSpace ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Miscellaneous_Claim_Creation _End_With_Special_Charc";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String JobCode)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.typeAndEnterJobCode(JobCode)
		.clickSubmit()
		.getdialogMsg()
		.closeDialogMsg();





	}

}
