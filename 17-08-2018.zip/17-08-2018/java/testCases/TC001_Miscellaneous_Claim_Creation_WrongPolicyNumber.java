package testCases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_Miscellaneous_Claim_Creation_WrongPolicyNumber extends PreAndPost{

	@BeforeClass
	public void setValues() {
		//browserName="internet explorer";
		browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous_Claim_Creation_WrongPolicyNumber";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001_Miscellaneous_Claim_Creation_WrongPolicyNumber";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String JobCode,String month,String year,String className,String rows, String col, String PolicyNumber)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceCreation()
		.typeAndEnterJobCode(JobCode)
		.clickandSelectDateOfLoss(month,year,className,rows, col)
		.typeAndChoosePolicyNumber(PolicyNumber)
		.clickSubmit()
		.getdialogMsg()
		.closeDialogMsg();





	}

}
