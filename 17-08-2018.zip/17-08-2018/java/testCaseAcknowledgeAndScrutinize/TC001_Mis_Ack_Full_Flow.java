package testCaseAcknowledgeAndScrutinize;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.Acknowledge;
import pages.LoginPage;

public class TC001_Mis_Ack_Full_Flow extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous Policy Ack_FullFlow ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Ack_Mis_Full_Full_For_Demo";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String dataACKRemarks)
					throws SikuliException, InterruptedException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu();
		Thread.sleep(2000);
		
		new Acknowledge()
		.clickAckbutton()
		.clickAckCheckGrid()
		.typeAckRemarks(dataACKRemarks)
		.clickACkGridSubmit()
		.ClickRemarkConfirmationYes()
		.getdialogMsg()
		.closeDialogMsg();





	}

}
