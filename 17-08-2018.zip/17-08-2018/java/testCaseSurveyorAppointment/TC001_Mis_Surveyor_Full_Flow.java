package testCaseSurveyorAppointment;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.Acknowledge;
import pages.LoginPage;
import pages.Surveyor_Appointment_Creation;

public class TC001_Mis_Surveyor_Full_Flow extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous Policy Ack_FullFlow ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Sur_Mis_Demo";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String dataSurCorporateCompan,String dataSurCreationClaimNo,String monthSAD,String yearSAD,String monthSCD, String yearSCD)
					throws SikuliException, InterruptedException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		Thread.sleep(2000);
		
		new Surveyor_Appointment_Creation()
		.clickSurveyorAppointmentMenu()
		.clickGridSurCreation_Edit()
		.SelectCheckCorporateSurveyorType()
		.typeAndEnterSurCompany(dataSurCorporateCompan)
		.typeSurCreationClaimNo(dataSurCreationClaimNo)
		.clickandSelectSurveyorAppointmentDate(monthSAD, yearSAD)
		.clickandSelectSurveyorClaimDate(monthSCD, yearSCD)
		.clickSurCreWindowSubmit()
		
		.getdialogMsg()
		.closeDialogMsg();





	}

}
