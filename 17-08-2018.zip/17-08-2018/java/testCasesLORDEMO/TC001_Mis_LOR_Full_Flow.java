package testCasesLORDEMO;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.Acknowledge;
import pages.Letter_Of_Requirement;
import pages.LoginPage;
import pages.Surveyor_Appointment_Creation;

public class TC001_Mis_LOR_Full_Flow extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="Miscellaneous Policy ";
		testDescription="Miscellaneous Policy LOR_FullFlow ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__LOR_Mis_Demo";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String dataCreationRemarks,String dataLORPSNO,String dataLORFileDesc,String filePath)
					throws SikuliException, InterruptedException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		Thread.sleep(2000);
		
		new Letter_Of_Requirement()
		.clickLOR()
		.clickLORCreate()
		.clickGridLORfirstvalueCreate()
		.ClickmaximizeButton()
		.typeAndEnterLORCreationRemarks(dataCreationRemarks)
		.typeAndEnterLORPSNO(dataLORPSNO)
		.ClickLORDocSubmit()
		.getdialogMsg()
		.closeDialogMsgYes()
		.getdialogMsg2()
		.closeDialogMsg()
		.ClickUploadLORDOC()
		.typeLORFileDesc(dataLORFileDesc)
		
		.FileUploadLOR(filePath)
		.ClickCloseWindow()
		
	
		;





	}

}
