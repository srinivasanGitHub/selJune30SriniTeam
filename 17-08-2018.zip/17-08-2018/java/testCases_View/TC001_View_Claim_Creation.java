package testCases_View;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_View_Claim_Creation extends PreAndPost {
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="View Policy Details ";
		testDescription="View Policy Details in Insurance Claim ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__View";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd)throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceView()
		.ClickinsideViewgrid();
		
	}

}
