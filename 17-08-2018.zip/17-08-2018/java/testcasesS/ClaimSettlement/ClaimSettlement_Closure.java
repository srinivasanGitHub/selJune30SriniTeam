package testcasesS.ClaimSettlement;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import pages.Claim_Settlement;

public class ClaimSettlement_Closure extends PreAndPost {
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="ClaimSettlement ";
		testDescription="ClaimSettlement_Creation";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001_ClaimSettlement_Closure";
		authors="Srinivasan";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String closureRemarks) throws SikuliException
	
	{
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		
		new Claim_Settlement()
		.clickClaimSettlementMenu()
		.clickeleClaimSettlementClosure()
		.typeClosureRemarks(closureRemarks);
		
		//.clickClaimSettlementCreationbutton()
		
			
	}

}
