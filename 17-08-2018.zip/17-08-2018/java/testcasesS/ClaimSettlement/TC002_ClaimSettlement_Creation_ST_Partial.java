package testcasesS.ClaimSettlement;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import pages.Claim_Settlement;

public class TC002_ClaimSettlement_Creation_ST_Partial extends PreAndPost {
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="ClaimSettlement ";
		testDescription="ClaimSettlement_Creation";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001_ClaimSettlement_Creation_ST_Partial";
		authors="Srinivasan";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String settlementType ,String ReceiptNum,String receiptDate,String bankDetails ,String assertAmount,
						 String grossAmount,String remarksData,String ReceiptNum1,String receiptDate1,String bankDetails1 ,String assertAmount1,
						 String grossAmount1,String remarksData1) throws SikuliException
	
	{
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		
		new Claim_Settlement()
		.clickClaimSettlementMenu()
		.clickClaimSettlementCreaActionGridFirst()
		//.clickClaimSettlementCreationbutton()
		.clickAddNewRecord()
		.clickandSelectSettlementType()
		.selectUsingTextSettlementType(settlementType)
		.typeReceiptNum(ReceiptNum)
		.typeReceiptDate(receiptDate)
		.typeBankDetails(bankDetails)
		.clickSettlementAmount()
		.clickAssetAddNewRecordGrid()
		.clickAssetType()
		.clickAssetTypeValue()
		//.typeAssetAmount(AssetAmount)
		//.typeAssetGrossassessedAmt(grossAmount)
		.clickAssetUpdateBtn()
		.clickSettlAmtProceed()
		.clickReceiptDetailEditBtn()
		.typeReceiptDetailsRemarks(remarksData)
		.clickReceiptDetailUpdateBtn()
		.clickAddNewRecord()
		.clickandSelectSettlementType()
		.selectUsingTextSettlementType(settlementType)
		.typeReceiptNum(ReceiptNum1)
		.typeReceiptDate(receiptDate1)
		.typeBankDetails(bankDetails1)
		.clickSettlementAmount()
		.clickAssetAddNewRecordGrid()
		.clickAssetType()
		.clickAssetTypeValue()
		//.typeAssetAmount(AssetAmount)
		//.typeAssetGrossassessedAmt(grossAmount)
		.clickAssetUpdateBtn()
		.clickSettlAmtProceed()
		.clickReceiptDetailEditBtn()
		.typeReceiptDetailsRemarks(remarksData1)
		.clickReceiptDetailUpdateBtn()
		.clickSettlementSubmit();
			
	}

}
