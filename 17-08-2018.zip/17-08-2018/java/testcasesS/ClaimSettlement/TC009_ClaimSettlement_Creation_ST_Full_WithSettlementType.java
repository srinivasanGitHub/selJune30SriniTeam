package testcasesS.ClaimSettlement;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import pages.Claim_Settlement;

public class TC009_ClaimSettlement_Creation_ST_Full_WithSettlementType extends PreAndPost {
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="ClaimSettlement ";
		testDescription="ClaimSettlement_Creation";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001_ClaimSettlement_Creation_ST_Full";
		authors="Srinivasan";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String settlementType ,String ReceiptNum,String receiptDate,String bankDetails ,String assertAmount,
						 String grossAmount) throws SikuliException
	
	{
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		
		new Claim_Settlement()
		.clickClaimSettlementMenu()
		.clickClaimSettlementCreaActionGridFirst()
		//.clickClaimSettlementCreationbutton()
		.clickAddNewRecord()
		.clickandSelectSettlementType()
		.selectUsingTextSettlementType(settlementType)
		.clickSettlementSubmit();
		
		
		
		//.getdialogMsg();
		
		
		
		
		
		
		
		
	}

}
