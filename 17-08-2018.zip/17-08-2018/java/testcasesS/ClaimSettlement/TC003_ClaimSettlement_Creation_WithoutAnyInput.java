package testcasesS.ClaimSettlement;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import pages.Claim_Settlement;

public class TC003_ClaimSettlement_Creation_WithoutAnyInput extends PreAndPost {
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="ClaimSettlement ";
		testDescription="ClaimSettlement_without fileds input";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC002_ClaimSettlement_Creation_WithoutAnyInput";
		authors="Srinivasan";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd) throws SikuliException
	
	{
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		
		new Claim_Settlement()
		.clickClaimSettlementMenu()
		.clickClaimSettlementCreaActionGridFirst()
		.clickAddNewRecord()
		.clickSettlementSubmit();
		
		
		
		
	}

}
