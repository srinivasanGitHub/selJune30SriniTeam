package testcasesS.ClaimSettlement;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;
import pages.Claim_Settlement;

public class TC006_ClaimSettlement_Creation_ClcikProceedBtnWithoutGivingAssertData extends PreAndPost {
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		//browserName="chrome";
		testCaseName="ClaimSettlement ";
		testDescription="ClaimSettlement_Creation_ClcikProceedBtnWithoutGivingAssertData";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC005_ClaimSettlement_Creation_AssertProceedBtnValidation";
		authors="Srinivasan";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String settlementType ,String ReceiptNum,String receiptDate,String bankDetails) throws SikuliException
	
	{
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin();
		
		new Claim_Settlement()
		.clickClaimSettlementMenu()
		.clickClaimSettlementCreaActionGridFirst()
		//.clickClaimSettlementCreationbutton()
		.clickAddNewRecord()
		.clickandSelectSettlementType()
		.selectUsingTextSettlementType(settlementType)
		.typeReceiptNum(ReceiptNum)
		.typeReceiptDate(receiptDate)
		.typeBankDetails(bankDetails)
		.clickSettlementAmount()
		.clickAssetAddNewRecordGrid()
		.clickAssetType()
		.clickSettlAmtProceed()
		.getdialogMsg();
		
		
		
		//.
		/*.clickReceiptCalender()
		.selectReceiptDate(year,month,date);*/
		
		
		
		
	}

}
