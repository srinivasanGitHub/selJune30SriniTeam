package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Acknowledge extends AbstractPage {
	
	public Acknowledge() {
		
		PageFactory.initElements(getEventDriver(), this);
	}
	
	
	@FindBy(how=How.XPATH,using="//button[@id='Acknowlede']")

	private WebElement eleAckbutton;
	public Acknowledge clickAckbutton() {
		click(eleAckbutton);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleACKFilter;
	public Acknowledge clickACKFilter() {
		pause(4);
		click(eleACKFilter);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleACKjobFilter;
	public Acknowledge clickACKJobFilter() {
		pause(4);
		click(eleACKjobFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleACKClaimFilter;
	public Acknowledge clickACKClaimFilter() {
		pause(4);
		click(eleACKClaimFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleAckClaimStatusbutton;
	public Acknowledge clickClaimStatusbutton(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAckClaimStatusbutton); 
		return this;
	}

	public Acknowledge selectUsingTexteleAckClaimStatus(String AckClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+AckClaimStatus+"']"), AckClaimStatus);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleACKPolicyNo;
	public Acknowledge typeAndEnterPolicyNo(String dataACKPolicyNo){
		pause(1);
		typeAndChoose(eleACKPolicyNo, dataACKPolicyNo); 
		return this;
	}
	
	

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleACKGetList;
	public Acknowledge clickACKGetList() {
		click(eleACKGetList);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleACKClose;
	public Acknowledge clickACKClose() {
		click(eleACKClose);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement elexClose;
	public Acknowledge clickxClose() {
		click(elexClose);
		return this;
	}
	
@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")
	
	private WebElement eleGridfirstvalue;
	public Acknowledge clickGridfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}

	@FindBy(how=How.XPATH,using="(//input[@class='checkboxA'])[1]")

	private WebElement eleAckCheckGrid;
	public Acknowledge clickAckCheckGrid() {
		click(eleAckCheckGrid);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//input[@class='checkboxR'])[1]")

	private WebElement eleSendBackCheckGrid;
	public Acknowledge clickSendBackCheck() {
		click(eleSendBackCheckGrid);
		return this;
	}

	@FindBy(how=How.XPATH,using="((//a[text()='Claim Cancel']/following::u))[3]")
	
	private WebElement eleGridCancel;
	public Acknowledge clickGridfristCancelButton() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridCancel);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='strFCremarks']")

	public WebElement eleACKRemarks;
	public Acknowledge typeAckRemarks(String dataACKRemarks){
		pause(1);
		type(eleACKRemarks, dataACKRemarks); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleACkPaginationRight;
	public Acknowledge clickACkPaginationRight() {
		click(eleACkPaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleACkPaginationRightlast;
	public Acknowledge clickACkPaginationRightlast() {
		click(eleACkPaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleACkPaginationLeft;
	public Acknowledge clickACkPaginationLeft() {
		click(eleACkPaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleACkPaginationLeftlast;
	public Acknowledge clickACkPaginationLeftlast() {
		click(eleACkPaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleAckPaginationItemPerPage;
	public Acknowledge clickAckPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAckPaginationItemPerPage); 
		return this;
	}

	public Acknowledge selectUsingTexteleAckItemperpage(String AckItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+AckItemPerPage+"']"), AckItemPerPage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='btnSubmit']")

	private WebElement eleACkGridSubmit;
	public Acknowledge clickACkGridSubmit() {
		click(eleACkGridSubmit);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public Acknowledge getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public Acknowledge closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Yes']")
	private WebElement eleRemarkConfirmationYes;
	public Acknowledge ClickRemarkConfirmationYes() 
	{

		click(eleRemarkConfirmationYes);

		return this;
	}
	
	
	
	
	
	
	

}
