package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EditClaimPage extends AbstractPage  {

	public static String dialogMessage;
	public EditClaimPage() {
		PageFactory.initElements(getEventDriver(), this);	
	}

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view Filter...!']")

	public WebElement eleClaimFilter;
	public EditClaimPage clickClaimFilter() {
		pause(4);
		click(eleClaimFilter);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='SelectedEditJobCode']")

	public WebElement eleEditJobCode;
	public EditClaimPage typeAndEnterJobCode(String dataeleEditJobCodeJobCode){
		pause(1);
		typeAndChoose(eleEditJobCode, dataeleEditJobCodeJobCode);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleEditClaimRefNo;
	public EditClaimPage typeAndEnterClaimRefNo(String dataEditClaimRefNo){
		pause(1);
		typeAndChoose(eleEditClaimRefNo, dataEditClaimRefNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedEditPolicyNo']")

	public WebElement eleEditPolicyNo;
	public EditClaimPage typeAndEnterPolicyNo(String dataEditPolicyNo){
		pause(1);
		typeAndChoose(eleEditPolicyNo, dataEditPolicyNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleClaimStatus;
	public EditClaimPage clickClaimStatus(){
		//click(eleCauseOfLoss);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleClaimStatus); 
		return this;
	}

	public EditClaimPage selectUsingTextClaimStatus(String ClaimStatus){
		selectUsingText(locateElement("xpath","//li[text()='"+ClaimStatus+"']"), ClaimStatus);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleGetList;
	public EditClaimPage clickGetList() {
		click(eleGetList);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleClose;
	public EditClaimPage clickClose() {
		click(eleClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement eleheaderClose;
	public EditClaimPage clickheaderClose() {
		click(eleheaderClose);
		return this;
	}

	//@FindBy(how=How.XPATH,using="(//u[text()=' Edit '])[1]")
	
	@FindBy(how=How.XPATH,using="(//u[text()=' Edit ']/../..)[1]")
	
	private WebElement eleGridEdit;
	public EditClaimPage clickGridEdit() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridEdit);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}

	@FindBy(how=How.XPATH,using="(//u[text()='WorkFlow'])[1]")

	private WebElement eleGridWorkFlow;
	public EditClaimPage clickGridWorkFlow() {
		pause(3);
		click(eleGridWorkFlow);
		pause(2);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNumber']")

	public WebElement eleEditPolicyNumber;
	public EditClaimPage typeAndChooseEditPolicyNumber(String dataEditPolicyNumber){
		pause(4);
		typeAndChoose(eleEditPolicyNumber, dataEditPolicyNumber);
		pause(1);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strprimarycause']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleEditCauseOfLoss;
	public EditClaimPage clickEditCauseOfLoss(){
		//click(eleCauseOfLoss);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleEditCauseOfLoss); 
		return this;
	}

	public EditClaimPage selectUsingTextEditCauseOfLoss(String EditCauseOfLoss){
		selectUsingText(locateElement("xpath","//li[text()='"+EditCauseOfLoss+"']"), EditCauseOfLoss);
		return this;
	}

	@FindBy(how=How.XPATH,using="//textarea[@id='occurency']")

	public WebElement eleEditOccuranceDetails;
	public EditClaimPage typeEditOccuranceDetails(String dataEditOccuranceDetails){
		type(eleEditOccuranceDetails, dataEditOccuranceDetails);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strTheftBurglary']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleEditTheftBurglary;
	public EditClaimPage clickEditTheftBurglary(){
		WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleEditTheftBurglary));
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleEditTheftBurglary); 
		return this;
	}

	public EditClaimPage selectUsingTextEditTheftBurglary(String EditTheftBurglary){
		selectUsingText(locateElement("xpath","//li[text()='"+EditTheftBurglary+"']"), EditTheftBurglary);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='firno']")

	public WebElement eleEditFIRNumber;
	public EditClaimPage typeEditFIRNumber(String dataEditFIRNumber){
		type(eleEditFIRNumber, dataEditFIRNumber);
		return this;
	}

	@FindBy(how=How.ID,using="datepickerHFIR")
	public WebElement eleEditFIRDate;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[1]")
	private WebElement eleEditFIRmonth;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[1]")
	private WebElement eleEditFIRyear;


	public EditClaimPage clickEditFIRDate(String FIRmonth, String FIRyear, String className2, String FIRrows, String FIRcol){
		datePicker(eleEditFIRDate, eleEditFIRmonth, eleEditFIRyear,className2, FIRmonth, FIRyear, FIRrows, FIRcol);

		return this;
	}

	@FindBy(how=How.XPATH,using="//ul[@id='strLostProperty_taglist']/..")
	public WebElement eleEditPropertyLostDamaged;
	public EditClaimPage clickEditPropertyLostDamaged(){

		mouseOverOnElement(eleEditPropertyLostDamaged);

		return this;
	}

	public EditClaimPage selectUsingTextEditPropertyLostDamaged(String PropertyLostDamaged1,String PropertyLostDamaged2){
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged1+"']"), PropertyLostDamaged1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged2+"']"), PropertyLostDamaged2);
		Actions builder=new Actions(getEventDriver());
		pause(2);
		builder.moveToElement(eleEditPropertyLostDamaged).sendKeys(Keys.ESCAPE);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strNewState']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleEditlocationLossState;
	public EditClaimPage clickEditlocationLossState(){
		WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleEditlocationLossState));
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleEditlocationLossState); 
		return this;
	}

	public EditClaimPage selectUsingTextEditlocationLossState(String EditlocationLossState){
		selectUsingText(locateElement("xpath","//li[text()='"+EditlocationLossState+"']"), EditlocationLossState);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strNewDistrict']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleEditlocationLossDistrict;
	public EditClaimPage clickEditlocationLossDistrict(){
		WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleEditlocationLossDistrict));
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleEditlocationLossDistrict); 
		return this;
	}

	public EditClaimPage selectUsingTextEditlocationLossDistrict(String EditlocationLossDistrict){
		selectUsingText(locateElement("xpath","//li[text()='"+EditlocationLossDistrict+"']"), EditlocationLossDistrict);
		return this;
	}


	@FindBy(how=How.XPATH,using="//label[text()='Excess Amount']/following::input")

	public WebElement eleEditExcessAmount;
	public EditClaimPage typeEditExcessAmount(String dataEditExcessAmount){
		type(eleEditExcessAmount, dataEditExcessAmount);
		return this;
	}

	@FindBy(how=How.XPATH,using="//label[text()='Estimate Value']/following::input")

	public WebElement eleEditEstimateValue;
	public EditClaimPage typeEditEstimateAmount(String dataEditEstimateValue){
		type(eleEditEstimateValue, dataEditEstimateValue);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[1]")

	public WebElement eleAddNewRecordGrid;
	public EditClaimPage clickAddNewRecordGrid(){

		((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAddNewRecordGrid);
		mouseOverOnElement(eleAddNewRecordGrid);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[2]")

	public WebElement eleAssetAddNewRecordGrid;
	public EditClaimPage clickAssetAddNewRecordGrid(){

		((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAssetAddNewRecordGrid);
		mouseOverOnElement(eleAssetAddNewRecordGrid);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[11]")

	public WebElement eleAssertDamage;
	public EditClaimPage clickAssertDamage(){
		//click(eleCauseOfLoss);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAssertDamage); 
		eleAssertDamage.sendKeys(Keys.ENTER);
		return this;
	}

	/*public EditClaimPage selectUsingTextTypeOfLoss(String TypeOfLoss){
		selectUsingText(locateElement("xpath","//li[text()='"+TypeOfLoss+"']"), TypeOfLoss);
		return this;
	}*/
	

	@FindBy(how=How.XPATH,using="//input[@id='strPsno']")

	public WebElement eleEditPSNOGrid;
	public EditClaimPage typeEditPSNOGrid(String dataPSNOGrid){
		typeAndChoose(eleEditPSNOGrid, dataPSNOGrid);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//a[text()='Edit']")

	public WebElement eleEditGrid;
	public EditClaimPage ClickEditGridButton(){
		click(eleEditGrid);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='strGContactno']")

	public WebElement eleEditMobileGrid;
	public EditClaimPage TypeGridtMobileNo(String dataMobileNo){
		type(eleEditMobileGrid,dataMobileNo);
		pause(1);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strGContactemail']")

	public WebElement eleEditEmailGrid;
	public EditClaimPage TypeGridEmailID(String dataEmailID){
		type(eleEditEmailGrid,dataEmailID);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	public WebElement eleUpdateGrid;
	public EditClaimPage ClickUpdateGridButton(){
		click(eleUpdateGrid);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Cancel']")

	public WebElement eleCancelGrid;
	public EditClaimPage ClickCancelGridButton(){
		click(eleCancelGrid);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//button[text()[contains(.,'Submit')]]")

	public WebElement eleEditSubmit;
	public EditClaimPage clickEditSubmit(){
		click(eleEditSubmit);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='delete'])[1]")

	public WebElement elePLDFirstOptionX;
	public EditClaimPage clickPLDFirstOptionX(){
		click(elePLDFirstOptionX);
		return this;
	}
	
	
	@FindBy(how=How.ID,using="strHOccurenceEnroot")

	public WebElement eleEditOccurenceEnroot;
	public EditClaimPage selectUsingTextEditOccurenceEnroot(String dataEditOccurenceEnroot) {
		selectUsingText(eleEditOccurenceEnroot,dataEditOccurenceEnroot);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//i[@class='fa fa-check']/..")

	public WebElement elegetClaimReqNo;
	public EditClaimPage getTextClaimReq(String dataEditClaimReqNo) {
		//selectUsingText(elegetClaimReqNo,dataEditClaimReqNo);
		dialogMessage = getText(elegetClaimReqNo);
		System.out.println(dialogMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='nameSearchString']")

	public WebElement eleWorkFlowNameAndPS;
	public EditClaimPage typeWorkFlowNameAndPS(String dataWorkFlowNameAndPS){
		type(eleWorkFlowNameAndPS, dataWorkFlowNameAndPS);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='materialList']")

	public WebElement eleworkFlowSearchButton;
	public EditClaimPage clickworkFlowSearchButton(){
		pause(3);
		click(eleworkFlowSearchButton);
		
		return this;
	}
	
	//@FindBy(how=How.XPATH,using="//div[@id='listMaterialAvailable']//following-sibling::div")
	//@FindBy(how=How.XPATH,using="//div[@id='listview']")
	@FindBy(how=How.XPATH,using="//label[@title='click to Select']")

	public WebElement eleworkFlowNameAndPSSelection;
	public EditClaimPage clickworkFlowNameAndPSSelection(){
		WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleworkFlowNameAndPSSelection));
		mouseOverOnElement(eleworkFlowNameAndPSSelection);
		return this;
	}

	
	
	@FindBy(how=How.XPATH,using="//textarea[@id='txtRemarks']")

	public WebElement eleWorkFlowRemarks;
	public EditClaimPage typeWorkFlowRemarks(String dataWorkFlowRemarks){
		pause(4);
		type(eleWorkFlowRemarks, dataWorkFlowRemarks);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='textButton']")

	public WebElement eleWorkFlowSubmit;
	public EditClaimPage clickworkFlowSubmit(){
		click(eleWorkFlowSubmit);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public EditClaimPage getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public EditClaimPage closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//label[@title='click to Select']")
	private WebElement elePsNoForMessage;
	public EditClaimPage PsNoForMessage() 
	{

		click(elePsNoForMessage);

		return this;
	}
	
	

	}
