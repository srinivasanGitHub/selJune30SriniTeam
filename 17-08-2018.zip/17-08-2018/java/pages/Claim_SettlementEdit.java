package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Claim_SettlementEdit extends AbstractPage {
	

	public Claim_SettlementEdit() {
		PageFactory.initElements(getEventDriver(), this);
	}
	
	

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleClaimSettlementEditFilter;
	public Claim_SettlementEdit clickClaimSettlementEditFilter() {
		pause(4);
		click(eleClaimSettlementEditFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleClaimSettlemenEditJobFilter;
	public Claim_SettlementEdit clickClaimSettlementEditJobFilter() {
		pause(4);
		click(eleClaimSettlemenEditJobFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleClaimSettlementEditClaimFilter;
	public Claim_SettlementEdit clickClaimSettlementEditClaimFilter() {
		pause(4);
		click(eleClaimSettlementEditClaimFilter);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleClaimSettlementEditClaimStatusbutton;
	public Claim_SettlementEdit clickClaimSettlementEditStatusbutton(){

		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleClaimSettlementEditClaimStatusbutton); 
		return this;
	}

	public Claim_SettlementEdit selectUsingTextClaimSettleEdit(String ClaimSettlementEditClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+ClaimSettlementEditClaimStatus+"']"), ClaimSettlementEditClaimStatus);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleClaimSettlementEditPolicyNo;

	public Claim_SettlementEdit typeAndEntereleClaimSettlementCreationPolicyNo(String dataClaimSettlementEditPolicyNo){
		pause(1);
		typeAndChoose(eleClaimSettlementEditPolicyNo, dataClaimSettlementEditPolicyNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleClaimSettlementEditGetList;
	public Claim_SettlementEdit clickClaimSettkGetList() {
		click(eleClaimSettlementEditGetList);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleClaimSettlementEditClose;
	public Claim_SettlementEdit clickLORViewClose() {
		click(eleClaimSettlementEditClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement eleClaimSettlementxCloseSur;
	public Claim_SettlementEdit clickClaimSettlementxCloseSur() {
		click(eleClaimSettlementxCloseSur);
		return this;
	}
	
	

}
