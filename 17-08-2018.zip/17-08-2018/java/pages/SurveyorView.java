package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SurveyorView extends AbstractPage {


	public SurveyorView(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleSurAppointViewFilter;
	public SurveyorView clickSurAppointViewFilter() {
		pause(4);
		click(eleSurAppointViewFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleSurveyor_ViewJobFilter;
	public SurveyorView clickSurveyor_AppointmentViewJobFilter() {
		pause(4);
		click(eleSurveyor_ViewJobFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleSurAppViewClaimFilter;
	public SurveyorView clickSurAppViewClaimFilter() {
		pause(4);
		click(eleSurAppViewClaimFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleSurClaimViewStatusbutton;
	public SurveyorView clickSurViewStatusbutton(){

		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleSurClaimViewStatusbutton); 
		return this;
	}

	public SurveyorView selectUsingTexteleSurClaimViewStatus(String SurClaimViewStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+SurClaimViewStatus+"']"), SurClaimViewStatus);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleSurViewPolicyNo;
	public SurveyorView typeAndEnterSurPolicyNo(String dataSurViewPolicyNo){
		pause(1);
		typeAndChoose(eleSurViewPolicyNo, dataSurViewPolicyNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleSurViewGetList;
	public SurveyorView clickSurViewGetList() {
		click(eleSurViewGetList);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleScruViewClose;
	public SurveyorView clickScruViewClose() {
		click(eleScruViewClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement elexCloseViewSur;
	public SurveyorView clickxCloseViewSur() {
		click(elexCloseViewSur);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")

	private WebElement eleGridSurViewfirstvalue;
	public SurveyorView clickGridSurViewfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridSurViewfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}


	@FindBy(how=How.XPATH,using="((//a[text()='Surveyer Appointment View']/following::u))[2]")

	private WebElement eleGridSurView;
	public SurveyorView clickGridSurView() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridSurView);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleSurAppViewPaginationRight;
	public SurveyorView clickSurAppViewPaginationRight() {
		click(eleSurAppViewPaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleSurAppViewPaginationRightlast;
	public SurveyorView clickSurAppPaginationRightlast() {
		click(eleSurAppViewPaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleSurAppViewPaginationLeft;
	public SurveyorView clickSurAppViewPaginationLeft() {
		click(eleSurAppViewPaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleSurAPPViewPaginationLeftlast;
	public SurveyorView clickSurAppViewPaginationLeftlast() {
		click(eleSurAPPViewPaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleSurViewPaginationItemPerPage;
	public SurveyorView clickSurViewPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleSurViewPaginationItemPerPage); 
		return this;
	}

	public SurveyorView selectUsingTexteleSurAPPItemperpage(String SurAppViewItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+SurAppViewItemPerPage+"']"), SurAppViewItemPerPage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[contains(text(), 'Top')]")

	private WebElement eleSurAPPViewTop;
	public SurveyorView clickSurAppViewTop() {
		click(eleSurAPPViewTop);
		return this;
	}
	
	
	


}
