package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class ViewClaimPage extends AbstractPage  {


	public ViewClaimPage() {
		PageFactory.initElements(getEventDriver(), this);	
	}

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleViewClaimFilter;
	public ViewClaimPage clickViewClaimFilter() {
		click(eleViewClaimFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleViewFilterJobCode;
	public ViewClaimPage typeAndEnterJobCode(String dataViewFilterJobCode){
		pause(1);
		typeAndChoose(eleViewFilterJobCode, dataViewFilterJobCode);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//u[text()='View'])[1]")

	public WebElement eleinsideviewbutton;
	public ViewClaimPage ClickinsideViewButton(){
		pause(1);
		click(eleinsideviewbutton);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::div//u)[1]")

	public WebElement eleinsideviewgrid;
	public ViewClaimPage ClickinsideViewgrid(){
		pause(1);
		click(eleinsideviewgrid);
		return this;
	}
	
	public ViewClaimPage scrollViewPage(){
		pause(3);
		 JavascriptExecutor js = (JavascriptExecutor)getEventDriver();
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Top')]")

	public WebElement eleClickTop;
	public ViewClaimPage clickTop(){
		click(eleClickTop);
		return this;
	}
	
	

}