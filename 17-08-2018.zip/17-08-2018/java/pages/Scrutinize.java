package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Scrutinize extends AbstractPage {
	
	public Scrutinize() {
		
		PageFactory.initElements(getEventDriver(), this);
	}
	
	
	@FindBy(how=How.XPATH,using="//button[@id='Scruntize']")

	private WebElement eleScrubutton;
	public Scrutinize clickScrubutton() {
	
		click(eleScrubutton);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleSCruFilter;
	public Scrutinize clickScruFilter() {
		pause(4);
		click(eleSCruFilter);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleScrujobFilter;
	public Scrutinize clickScruJobFilter() {
		pause(4);
		click(eleScrujobFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleScruClaimFilter;
	public Scrutinize clickScruClaimFilter() {
		pause(4);
		click(eleScruClaimFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleScruClaimStatusbutton;
	public Scrutinize clickScruStatusbutton(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleScruClaimStatusbutton); 
		return this;
	}

	public Scrutinize selectUsingTexteleAckClaimStatus(String ScruClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+ScruClaimStatus+"']"), ScruClaimStatus);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleSCruPolicyNo;
	public Scrutinize typeAndEnterPolicyNo(String dataScruPolicyNo){
		pause(1);
		typeAndChoose(eleSCruPolicyNo, dataScruPolicyNo); 
		return this;
	}
	
	

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleScruGetList;
	public Scrutinize clickScruGetList() {
		click(eleScruGetList);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleScruClose;
	public Scrutinize clickScruClose() {
		click(eleScruClose);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement elexClosescru;
	public Scrutinize clickxCloseScru() {
		click(elexClosescru);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")
	
	private WebElement eleGridscrufirstvalue;
	public Scrutinize clickGridScrufirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridscrufirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}

	@FindBy(how=How.XPATH,using="(//input[@class='checkboxR'])[1]")

	private WebElement eleSendBack;
	public Scrutinize clicSendBack() {
		click(eleSendBack);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="(//a[text()='Scrutinize']/following::u)[2]")
	
	private WebElement eleGridfirstScru;
	public Scrutinize clickGridfirstScru() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridfirstScru);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		pause(8);
		return this;
	}
	
	

	@FindBy(how=How.XPATH,using="((//a[text()='Claim Cancel']/following::u))[3]")
	
	private WebElement eleGridCancel;
	public Scrutinize clickGridfristCancelButton() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridCancel);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='strFCremarks']")

	public WebElement eleScruRemarks;
	public Scrutinize typeScruRemarks(String dataScruRemarks){
		pause(1);
		type(eleScruRemarks, dataScruRemarks); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleScruPaginationRight;
	public Scrutinize clickACkPaginationRight() {
		click(eleScruPaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleScruPaginationRightlast;
	public Scrutinize clickScruPaginationRightlast() {
		click(eleScruPaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleScruPaginationLeft;
	public Scrutinize clickACkPaginationLeft() {
		click(eleScruPaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleScruPaginationLeftlast;
	public Scrutinize clickScruPaginationLeftlast() {
		click(eleScruPaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleScruPaginationItemPerPage;
	public Scrutinize clickScruPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleScruPaginationItemPerPage); 
		return this;
	}

	public Scrutinize selectUsingTexteleAckItemperpage(String AckItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+AckItemPerPage+"']"), AckItemPerPage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='btnSubmit']")

	private WebElement eleScruGridSubmit;
	public Scrutinize clickScruGridSubmit() {
		click(eleScruGridSubmit);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public Scrutinize closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public Scrutinize getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//div[text()='Scrutinize Remarks']/following::textarea")

	public WebElement eleScruRemark;
	public Scrutinize typeScrutinizeRemarks(String dataACKPolicyNo){
		pause(4);
		//click(eleACKPolicyNo);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleACKPolicyNo); */
		//mouseOverOnElement(eleScruRemark);
		//pause(1);
		try {
			getEventDriver().executeScript("eleScruRemark.scroll();","");
			eleScruRemark.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		type(eleScruRemark, dataACKPolicyNo); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()[contains(.,'Submit')]]")

	public WebElement eleSubmit;
	public Scrutinize clickSubmit(){
		click(eleSubmit);
		return this;
	}
	

}
