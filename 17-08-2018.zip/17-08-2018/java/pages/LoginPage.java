package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.sikuli.script.SikuliException;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;

public class LoginPage extends AbstractPage{

	String sessionId ="";


	public LoginPage() {
		PageFactory.initElements(getEventDriver(), this);
	}


	@FindBy(how = How.ID, using = "txtUserName")
	private WebElement eleUName;

	@FindBy(how = How.ID, using = "txtPassword")
	private WebElement elePassword;

	@FindBy(how = How.ID, using = "btnLogin")
	private WebElement eleLogin;
	
	@FindBy(how = How.XPATH, using = "//input[@alt='Insurance']")
	private WebElement eleInsurance;
	@FindBy(how = How.XPATH, using = "//input[@title='Claims']")
	private WebElement eleClaims;
	
	
	
	@And("Username is entered")
	public LoginPage enterUserName(String data) {
		typeAndTab(eleUName, data); 
		return this;
	}
	@And("Password is entered")
	public LoginPage enterPassword(String data) {
		System.out.println("The trimvalue is"+getAttributeText(elePassword, "value").trim());
		if(getAttributeText(elePassword, "value").trim().equals(""))
			type(elePassword, data);
		return this;
	}


	/*public InsuranceClaim clicklogin() {

		click(eleLogin);

		String currentUrl = getEventDriver().getCurrentUrl();		
		if(currentUrl.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		//System.out.println("Session:"+sessionId);

		 // getEventDriver().get(config.getProperty("URL")+"/InsuranceNew/CommonGetSession.aspx?strpage=INSHome/INSHomeUI&SessionID="+sessionId);
		//getEventDriver().get(config.getProperty("URL")+"/InsuranceNew/INS/CommonGetSession.aspx?strpage=INSHome/INSHomeUI&SessionID="+sessionId);
		//getEventDriver().get(config.getProperty("URL")+"/InsuranceNet/CommonGetSession.aspx?strpage=INSCLMMgmt/INSCLMEmpMenu.aspx&SessionID="+sessionId);
		//getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
		//getEventDriver().get(config.getProperty("URL")+"/PMP/CommonGetSession.aspx?strpage=UI/Reports/PMPRExecutiveJCR.aspx&SessionID="+sessionId);
		//getEventDriver().get(config.getProperty("URL")+"/InsuranceNew/CommonGetSession.aspx?strpage=INSHome/INSHomeUI&Module=InsuranceNew&SessionID="+sessionId);
        //getEventDriver().get(config.getProperty("URL")+"/InsuranceNew/CommonGetSession.aspx?strpage=INSHome/INSHomeUI&SessionID="+sessionId);


		//getDriver().navigate().to("https://eipdev.lntecc.com/MemberPage/ReDirectPage.aspx?strPage=INSHome/INSHomeUI&Module=InsuranceNew"); 

	 
		getDriver().get(config.getProperty("URL")+"/InsuranceNew/CommonGetSession.aspx?strpage=INSHome/INSHomeUI&SessionID="+sessionId);
		return new InsuranceClaim();



	}*/

	public InsuranceClaim clicklogin() throws SikuliException {
		String currentUrl = getEventDriver().getCurrentUrl();
		click(eleLogin);

		if(((RemoteWebDriver)getDriver()).getCapabilities().getBrowserName().equalsIgnoreCase("chrome")) {
			click(eleInsurance);
			click(eleClaims);
		}else {
			pause(10);
			sikuli("./Tiles/INSTile.png");
			pause(10);
			sikuli("./Tiles/Claims.png");
		}
		return new InsuranceClaim();
	} 
	
	public LoginPage InvalidCredentials()
	{
		
		click(eleLogin);
		return this;
	}
	
	public LoginPage AcceptalertforInvalidCredentials()
	{
		
		acceptAlert();
		return this;
	}

	public LoginPage AlertTextLoginpage(String TextData)
	{
		
		String textAlert = getTextAlert();
		if( textAlert.equalsIgnoreCase(TextData))
		{
			reportStep("Alert Text is  " +textAlert, "PASS");
		}
		
		else
		{
			reportStep("Alert Text is  " +textAlert, "FAIL");
		}
		return this;
	}

}
