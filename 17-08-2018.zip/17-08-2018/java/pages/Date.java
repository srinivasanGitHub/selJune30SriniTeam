package pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

public class Date {

	public static void main(String[] args) throws InterruptedException, FindFailed {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.ie.driver","./drivers/IEDriverServer.exe");
		//InternetExplorerDriver driver=new InternetExplorerDriver();
		
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get("https://eipdev.lntecc.com");
		driver.manage().window().maximize();
		driver.findElementById("txtUserName").sendKeys("gkkumar");
		driver.findElementById("txtPassword").sendKeys("dummy123");
		driver.findElementById("btnLogin").click();
		Actions builder=new Actions(driver);
		WebElement InsTile = driver.findElementByXPath("//input[@alt='Insurance']");
		builder.moveToElement(InsTile).build().perform();
		InsTile.click();
		WebElement ClaimTile = driver.findElementByXPath("//input[@title='Claims']");
		builder.moveToElement(ClaimTile).build().perform();
		ClaimTile.click();
		
		/*Screen screen = new Screen();
		
		
		Pattern image = new Pattern("INSTile.PNG");
		
		
		screen.wait(image, 10);

		   

		//Click on the image

		screen.click(image);
         
		Pattern image1 = new Pattern("C:\\images\\uname.PNG");

		Pattern image2 = new Pattern("C:\\images\\password.PNG");*/
		
		driver.findElementByXPath("//span[text()='Insurance Claim']").click();
		Thread.sleep(3000);
		driver.findElementByXPath("//button[@id='Creation']").click();
		Thread.sleep(3000);
		WebElement jobcode = driver.findElementByXPath("//input[@id='SelectedJobCode']");
		jobcode.sendKeys("CEIC6381");
		Thread.sleep(3000);
		jobcode.sendKeys(Keys.DOWN,Keys.ENTER);
		
		
		
		driver.findElementById("datess").click();
		Select DOL = new Select(driver.findElement(By.className("monthselect")));
		DOL.selectByValue("5");
		Select Year=new Select(driver.findElementByClassName("yearselect"));
		Year.selectByValue("2015");
		
		
		WebDriverWait wait=new WebDriverWait(driver, 30);
		//WebElement datePicker=wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("calendar-table")));
		WebElement datePicker=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='calendar-table']/table/thead/tr/following::tbody")));
		//Store Rows in list and get size of row and print
		
		List<WebElement> allRows = datePicker.findElements(By.tagName("tr"));
		int size = allRows.size();
		System.out.println(size);
		
		
		//Get Row and Store all colun in list
		
		WebElement row = allRows.get(4);
		List<WebElement> listRowForColumn = row.findElements(By.tagName("td"));
		listRowForColumn.get(1).click();
		
		WebElement pn = driver.findElementByXPath("//input[@id='SelectedPolicyNumber']");//.sendKeys("111600/21/2005/50135/31");
		pn.sendKeys("111600/21/2005/50135/31");
		Thread.sleep(3000);
		pn.sendKeys(Keys.DOWN,Keys.ENTER);
		
	/*//	String attribute = driver.findElementByXPath("(//input[@id='policytype'])[1]").getAttribute("value");
		String attribute =driver.findElementByCssSelector("INS.strHpolicycode").getAttribute("value");
		System.out.println(attribute);
		//((JavascriptExecutor)driver).executeScript("angular.element($('policytype'))l.text()";
		WebElement elementByXPath = driver.findElementByXPath("(//input[@id='policytype'])[1]");
		//return (String) ((JavascriptExecutor) this.webDriver).executeScript("angular.element($('#endDate')).text()");
		//String attribute=((JavascriptExecutor).driver).executeScript("angular.element($('#endDate')).text()");
		Object executeScript = ((JavascriptExecutor)driver).executeScript("elementByXPath.text()");
		System.out.println(executeScript);*/
		
				String attribute = driver.findElementByXPath("(//input[@id='policytype'])[1]").getAttribute("value");
		
		System.out.println(attribute);
		
		
		
	}

}
