package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class InsuranceClaim extends AbstractPage  {

	List<String> dateAndMoneyUI, dateAndMoneyDB;

	public InsuranceClaim(){
		
 		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how=How.XPATH,using="//span[text()='Insurance Claim']")

	private WebElement eleInsuranceClaimMenu;
	public InsuranceClaim clickInsuranceClaimMenu() {
		click(eleInsuranceClaimMenu);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[@id='Creation']")

	private WebElement eleInsurnaceCreation;
	public InsuranceClaim clickInsuranceCreation() {
		click(eleInsurnaceCreation);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleJobCode;
	public InsuranceClaim typeAndEnterJobCode(String dataJobCode){
		pause(3);
		typeAndChoose(eleJobCode, dataJobCode);
		return this;
	}

	@FindBy(how=How.ID,using="datess")
	private WebElement eleDateOfLoss;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[1]")
	private WebElement elemonth;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[1]")
	private WebElement eleyear;


	public InsuranceClaim clickandSelectDateOfLoss(String month, String year,String classname, String rows, String col){

		datePicker(eleDateOfLoss, elemonth, eleyear,classname, month, year, rows, col);
		return this;
	}
		
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNumber']")

	public WebElement elePolicyNumber;
	public InsuranceClaim typeAndChoosePolicyNumber(String dataPolicyNumber){
		typeAndChoose(elePolicyNumber, dataPolicyNumber);
		pause(2);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//input[@id='policytype'])[2]")

	public WebElement eleWorkmanName;
	public InsuranceClaim typeWorkman(String dataWorkMan){
		type(eleWorkmanName, dataWorkMan);
		pause(2);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='policytype']")

	public WebElement elePolicyType;
	public InsuranceClaim verifyExactTextPolicyType(String dataPolicyType){
		verifyText(elePolicyType, dataPolicyType);
		//((JavascriptExecutor) this.getEventDriver()).executeScript(" $('INS.strHpolicycode').text()");

		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='insurancecompanydetails']")

	public WebElement eleInsuranceCompanyDetail;
	public InsuranceClaim verifyExactTextInsuranceCompanyDetail(String dataInsuranceCompanyDetail){
		verifyText(eleInsuranceCompanyDetail, dataInsuranceCompanyDetail);
		return this;
	}



	@FindBy(how=How.XPATH,using="//input[@id='strprimarycause']/preceding-sibling::span")

	public WebElement eleCauseOfLoss;
	public InsuranceClaim clickCauseOfLoss(){
		//click(eleCauseOfLoss);
		WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleCauseOfLoss));
		//getEventDriver().executeScript("eleCauseOfLoss.scroll();","");
	

		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleCauseOfLoss); 
		return this;
	}

	public InsuranceClaim selectUsingTextCauseOfLoss(String CauseOfLoss){
		pause(1);
		List<WebElement> list = getEventDriver().findElements(By.xpath("//div[@id='strprimarycause-list']//li"));
		int size = list.size();
		try {
			getEventDriver().executeScript("list.get(1).scroll();","");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		getEventDriver().executeScript("arguments[0].click();",list.get(size-2)); 
	//	scrollandselectUsingText(locateElement("xpath","//li[text()='"+CauseOfLoss+"']"), CauseOfLoss);
		
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='SelectedEmployee']")

	public WebElement eleEmployeeNumber;
	public InsuranceClaim typeAndChooseEmployeeNumber(String dataEmployeeNumber){
		typeAndChoose(eleEmployeeNumber, dataEmployeeNumber);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='employeeName']")

	public WebElement eleEmployeeName;
	public InsuranceClaim verifyExactTextEmployeeName(String dataEmployeeName){
		verifyText(eleEmployeeName, dataEmployeeName);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@id='employeedepartment']")

	public WebElement eleEmployeeDepartment;
	public InsuranceClaim verifyExactTextEmployeeDepartment(String dataEmployeeDepartment){
		verifyText(eleEmployeeDepartment, dataEmployeeDepartment);
		return this;
	}


	@FindBy(how=How.XPATH,using="//textarea[@id='occurency']")

	public WebElement eleOccuranceDetails;
	public InsuranceClaim typeOccuranceDetails(String dataOccuranceDetails){
		type(eleOccuranceDetails, dataOccuranceDetails);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='strTheftBurglary']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleTheftBurglary;
	public InsuranceClaim clickTheftBurglary(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleTheftBurglary); 
		return this;
	}

	public InsuranceClaim selectUsingTextTheftBurglary(String TheftBurglary){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+TheftBurglary+"']"), TheftBurglary);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='firno']")

	public WebElement eleFIRNumber;
	public InsuranceClaim typeFIRNumber(String dataFIRNumber){
		pause(1);
		type(eleFIRNumber, dataFIRNumber);
		return this;
	}

	/*@FindBy(how=How.ID,using="datepickerHFIR")
	public WebElement eleFIRDate;
	public InsuranceClaim clickFIRDate(String month, String year, String rows, String co1){
		datePicker(eleFIRDate, month, year, rows, co1);

		return this;
	}*/

	@FindBy(how=How.ID,using="datepickerHFIR")
	public WebElement eleFIRDate;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[3]")
	private WebElement eleFIRmonth;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[3]")
	private WebElement eleFIRyear;


	public InsuranceClaim clickFIRDate(String FIRmonth, String FIRyear, String className2, String FIRrows, String FIRcol){
		datePicker(eleFIRDate, eleFIRmonth, eleFIRyear,className2, FIRmonth, FIRyear, FIRrows, FIRcol);

		return this;
	}


	/*@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[3]")

	public WebElement eleModeOfTransport;
	public InsuranceClaim selectUsingTextModeOfTransport(String dataModeOfTransport) {
		selectUsingText(eleModeOfTransport,dataModeOfTransport);
		return this;
	}*/

	@FindBy(how=How.XPATH,using="//input[@id='strModeTransport']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleModeOfTransport;
	public InsuranceClaim clickModeOfTransport(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleModeOfTransport); 
		return this;
	}

	public InsuranceClaim selectUsingTextModeOfTransport(String ModeOfTransport){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+ModeOfTransport+"']"), ModeOfTransport);
		return this;
	}

	/*
	@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[4]")

	public WebElement eleDeliveryTermsAsPerPo;
	public InsuranceClaim selectUsingTextDeliveryTermAsPerPo(String dataDeliveryTermAsPerPo) {
		selectUsingText(eleDeliveryTermsAsPerPo,dataDeliveryTermAsPerPo);
		return this;
	}*/


	@FindBy(how=How.XPATH,using="//input[@id='strDeliveryProperty']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleDeliveryProperty;
	public InsuranceClaim clickDeliveryProperty(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleDeliveryProperty); 
		return this;
	}

	public InsuranceClaim selectUsingTexteleDeliveryProperty(String DeliveryProperty){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+DeliveryProperty+"']"), DeliveryProperty);
		return this;
	}



	@FindBy(how=How.ID,using="strHOccurenceEnroot")

	public WebElement eleOccurenceEnroot;
	public InsuranceClaim selectUsingTextOccurenceEnroot(String dataOccurenceEnroot) {
		selectUsingText(eleOccurenceEnroot,dataOccurenceEnroot);
		return this;
	}


	@FindBy(how=How.ID,using="datepicker")
	private WebElement eleDateOfReceiptOfConsignmentAtSite;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[5]")
	private WebElement elemonthreceipt;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[5]")
	private WebElement eleyearreceipt;


	public InsuranceClaim clickandSelectDateOfReceiptOfConsignmentAtSite(String monthR, String yearR,String classnameR, String rowsR, String colR){

		datePicker(eleDateOfReceiptOfConsignmentAtSite, elemonthreceipt, eleyearreceipt,classnameR, monthR, yearR, rowsR, colR);
		return this;
	}

	/*@FindBy(how=How.XPATH,using="//label[text()='Date when consignment was Unpacked ']/following::input")

	public WebElement eleDateWhenConsignmentWasUnpacked;
	public InsuranceClaim clickAndSelectDateWhenConsignmentWasUnpacked(String month, String year, String rows, String col) {
		//datePicker(eleDateWhenConsignmentWasUnpacked, month, year, rows, col);
		return this;
	}*/

	@FindBy(how=How.ID,using="datepicker1")
	private WebElement eleConsignmentWasUnpacked;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[3]")
	private WebElement elemonthUnpacked;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[3]")
	private WebElement eleyearUnpacked;


	public InsuranceClaim clickandSelectUnpacked(String monthU, String yearU,String classnameU, String rowsU, String colU){

		datePicker(eleConsignmentWasUnpacked, elemonthUnpacked, eleyearUnpacked,classnameU, monthU, yearU, rowsU, colU);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='invoicevalue']")

	public WebElement eleInvoiceValue;
	public InsuranceClaim typeAndChooseInvoiceValue(String dataInvoiceValue){
		type(eleInvoiceValue, dataInvoiceValue);
		return this;
	}

	/*@FindBy(how=How.XPATH,using="//ul[@id='strLostProperty_taglist']/..")

	public WebElement elePropertyLostDamaged;
	public InsuranceClaim selectUsingTextPropertyLostDamaged(String dataPropertyLostDamaged1){
		selectUsingText(elePropertyLostDamaged, dataPropertyLostDamaged1); 
		//selectUsingText(elePropertyLostDamaged,dataPropertyLostDamaged2);
		return this;
	}*/

	//@FindBy(how=How.XPATH,using="//select[@id='strLostProperty']/preceding-sibling::div/input")
	@FindBy(how=How.XPATH,using="//ul[@id='strLostProperty_taglist']/../..")
	public WebElement elePropertyLostDamaged;
	public InsuranceClaim clickPropertyLostDamaged(){
		
		click(elePropertyLostDamaged);
		//wait.until(ExpectedConditions.visibilityOf(elePropertyLostDamaged));
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",elePropertyLostDamaged); */
		/*Actions builder=new Actions(getEventDriver());
		builder.moveToElement(elePropertyLostDamaged).click().perform();*/
		try {
			getEventDriver().executeScript("elePropertyLostDamaged.scroll();","");
			pause(4);
			mouseOverOnElement(elePropertyLostDamaged);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("For this scenario mouseover function not need");
		}

		return this;
	}

	public InsuranceClaim selectUsingTextPropertyLostDamaged(String PropertyLostDamaged1,String PropertyLostDamaged2){
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged1+"']"), PropertyLostDamaged1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged2+"']"), PropertyLostDamaged2);
		Actions builder=new Actions(getEventDriver());
		pause(3);
		builder.moveToElement(elePropertyLostDamaged).sendKeys(Keys.ESCAPE);
		//elePropertyLostDamaged.sendKeys(Keys.ESCAPE);
		return this;
	}

	public InsuranceClaim selectUsingTextPropertyLostDamaged1(String PropertyLostDamaged1){
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged1+"']"), PropertyLostDamaged1);

		Actions builder=new Actions(getEventDriver());
		pause(3);
		builder.moveToElement(elePropertyLostDamaged).sendKeys(Keys.ESCAPE);
		//elePropertyLostDamaged.sendKeys(Keys.ESCAPE);
		return this;
	}

	public InsuranceClaim selectUsingTextPropertyLostDamagedAll3(String PropertyLostDamaged1,String PropertyLostDamaged2,String PropertyLostDamaged3,String PropertyLostDamaged4,String PropertyLostDamaged5){
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged1+"']"), PropertyLostDamaged1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged2+"']"), PropertyLostDamaged2);
		pause(1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged3+"']"), PropertyLostDamaged3);
		pause(1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged4+"']"), PropertyLostDamaged4);
		pause(1);
		selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged5+"']"), PropertyLostDamaged5);
		//selectUsingText(locateElement("xpath","//li[text()='"+PropertyLostDamaged2+"']"), PropertyLostDamaged6);


		Actions builder=new Actions(getEventDriver());
		pause(3);
		builder.moveToElement(elePropertyLostDamaged).sendKeys(Keys.ESCAPE);
		//elePropertyLostDamaged.sendKeys(Keys.ESCAPE);
		return this;

	}
	@FindBy(how=How.XPATH,using="//label[text()='Others Property Loss']/../div/input")

	public WebElement eleOtherPropertyLoss;
	public InsuranceClaim typeOtherPropertyLoss(String dataOtherPropertyLoss){
		type(eleOtherPropertyLoss, dataOtherPropertyLoss);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ic']")

	public WebElement eleIndependentCompany;
	public InsuranceClaim verifyExactTextIndependentCompany(String dataIndependentCompany){
		verifyText(eleIndependentCompany, dataIndependentCompany);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//input[@id='budetails'])[1]")

	public WebElement elePolicyValidFrom;
	public InsuranceClaim verifyExactTextPolicyValidFrom(String dataPolicyValidFrom){
		verifyText(elePolicyValidFrom, dataPolicyValidFrom);
		return this;
	}
	@FindBy(how=How.XPATH,using="(//input[@id='budetails'])[2]")

	public WebElement elePolicyValidTo;
	public InsuranceClaim verifyExactTextPolicyValidTo(String dataPolicyValidTo){
		verifyText(elePolicyValidTo, dataPolicyValidTo);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//input[@id='budetails'])[3]")

	public WebElement eleSumInsured;
	public InsuranceClaim verifyExactTextSumInsured(String dataSumInsured){
		verifyText(eleSumInsured, dataSumInsured);
		return this;
	}

	@FindBy(how=How.XPATH,using="//label[text()='Excess Amount']/following::input")

	public WebElement eleExcessAmount;
	public InsuranceClaim typeExcessAmount(String dataExcessAmount){
		type(eleExcessAmount, dataExcessAmount);
		return this;
	}

	@FindBy(how=How.XPATH,using="//label[text()='Estimate Value']/following::input")

	public WebElement eleEstimateValue;
	public InsuranceClaim typeEstimateValue(String dataEstimateValue){
		type(eleEstimateValue, dataEstimateValue);
		return this;
	}

	@FindBy(how=How.XPATH,using="//textarea[@id='cargodescription']")

	public WebElement eleCargoDesc;
	public InsuranceClaim typeCargoDesc(String dataCargoDesc){
		type(eleCargoDesc, dataCargoDesc);
		return this;
	}


	@FindBy(how=How.XPATH,using="//select[@id='deriversign']")

	public WebElement eleDriverSignObtained;
	public InsuranceClaim selectUsingValueDriverSignObtained(String dataDeriverSign){
		//click(eleDriverSignObtained);
		selectUsingText(eleDriverSignObtained, dataDeriverSign);
		return this;
	}

	@FindBy(how=How.XPATH,using="//textarea[@id='conditionofconsignment']")

	public WebElement eleConditionOfConsignmentDuringUnpacking;
	public InsuranceClaim typeeleConditionOfConsignmentDuringUnpacking(String dataCOCDU){
		type(eleConditionOfConsignmentDuringUnpacking, dataCOCDU);
		return this;
	}

	/*@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[9]")

	public WebElement elePlantAndMachineryItem;
	public InsuranceClaim selectUsingTextPlantAndMachineryItem(String dataPlantAndMachineryItem) {
		selectUsingText(elePlantAndMachineryItem,dataPlantAndMachineryItem);
		return this;
	}	*/


	@FindBy(how=How.XPATH,using="//input[@id='strPMItem']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement elePlantAndMachineryItem;
	public InsuranceClaim clickPlantAndMachineryItem(){

		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",elePlantAndMachineryItem); 
		return this;
	}

	public InsuranceClaim selectUsingTextPlantAndMachineryItem(String PlantAndMachineryItem){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+PlantAndMachineryItem+"']"), PlantAndMachineryItem);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[10]")

	public WebElement eleCarrierToClaimCompensation;
	public InsuranceClaim selectUsingTexteleCarrierToClaimCompensation(String dataeleCarrierToClaimCompensation) {
		selectUsingText(eleCarrierToClaimCompensation,dataeleCarrierToClaimCompensation);
		return this;
	}	

	@FindBy(how=How.XPATH,using="//input[@id='sendingletter']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement elesendingletter;
	public InsuranceClaim clicksendingletter(){

		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",elesendingletter); 
		return this;
	}

	public InsuranceClaim selectUsingTextsendingletter(String sendingletter){
		pause(2);
		selectUsingText(locateElement("xpath","(//li[text()='"+sendingletter+"'])[2]"), sendingletter);
		return this;
	}
	
	
/*	@FindBy(how=How.ID,using="datepicker9")  ----Need to work
	private WebElement eleLikely;
	@FindBy(how=How.XPATH,using="(//label[text()='Likely date of sending letter against Carrier to claim compensation']/following::select[@class='monthselect'])[3]")
	private WebElement elemonthLikely;
	@FindBy(how=How.XPATH,using="(//label[text()='Likely date of sending letter against Carrier to claim compensation']/following::select[@class='yearselect'])[3]")
	private WebElement eleyearLikely;


	public InsuranceClaim clickandSelectYearLikely(String MonthLikely, String yearLikely){

		selectDate(eleTransportedFrom, "Transported from", MonthLikely, yearLikely, "1");
		return this;
	}*/
	

	/*@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[5]")

	public WebElement eleTypeOfLoss;
	public InsuranceClaim selectUsingTextTypeOfLoss(String dataTypeOfLoss){
		selectUsingText(eleTypeOfLoss, dataTypeOfLoss);
		return this;
	}
	 */

	@FindBy(how=How.XPATH,using="//input[@id='strTypeofloss']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleTypeOfLoss;
	public InsuranceClaim clickTypeOfLoss(){
		//click(eleCauseOfLoss);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleTypeOfLoss); 
		return this;
	}

	public InsuranceClaim selectUsingTextTypeOfLoss(String TypeOfLoss){
		selectUsingText(locateElement("xpath","//li[text()='"+TypeOfLoss+"']"), TypeOfLoss);
		return this;
	}



	@FindBy(how=How.XPATH,using="//input[@id='lorryregno']")

	public WebElement eleVehicleRegNo;
	public InsuranceClaim typeVehicleRegNo(String dataVehicleRegNo){
		type(eleVehicleRegNo, dataVehicleRegNo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='lrno']")

	public WebElement eleVehicleLRNo;
	public InsuranceClaim typeVehicleLRNo(String dataVehicleLRNo){
		type(eleVehicleLRNo, dataVehicleLRNo);


		return this;
	}

	/*@FindBy(how=How.ID,using="datepickerLRDate")

	public WebElement eleVehicleLRDate;
	public InsuranceClaim clickVehicleLRDate(String month, String year, String rows, String co1){
		//datePicker(eleVehicleLRDate, month, year, rows, co1);

		return this;
	}*/

	@FindBy(how=How.ID,using="datepickerLRDate")
	private WebElement eleLRDate;
	/*@FindBy(how=How.XPATH,using="")
	private WebElement eleyearLRDate;*/
	/*@FindBy(how=How.XPATH,using="//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]")
	private WebElement eleLrTable;*/


	public InsuranceClaim clickandSelectLRDate(String monthLr, String yearLR){
		click(eleLRDate);
		/*WebElement elemonthLRDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='monthselect']");
		selectUsingText(elemonthLRDate, monthLr);
		WebElement eleyearLRDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']");
		selectUsingText(eleyearLRDate,yearLR );
		WebElement eleDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']/following::td[text()='1']");
		click(eleDate);*/
		
		selectDate1(eleLRDate, "Vehicle LR Date", monthLr, yearLR, "1");
		return this;
	}
	
	
	@FindBy(how=How.ID,using="datepicker9")
	private WebElement eleSLetterDate;
	
	public InsuranceClaim clickandSelectSendingLetterDate(String monthSLetter, String SLetter){
		click(eleSLetterDate);
		/*WebElement elemonthLRDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='monthselect']");
		selectUsingText(elemonthLRDate, monthLr);
		WebElement eleyearLRDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']");
		selectUsingText(eleyearLRDate,yearLR );
		WebElement eleDate = locateElement("xpath", "//label[text()='Vehicle LR Date']/following::div[contains(@class,'show-calendar') and contains(@style,'block')]//select[@class='yearselect']/following::td[text()='1']");
		click(eleDate);*/
		
		selectDate2(eleSLetterDate, "Likely date of sending letter against Carrier to claim compensation", monthSLetter, SLetter, "1");
		return this;
	}



	/*@FindBy(how=How.ID,using="datepickerTransportedFrom")

	public WebElement eleTransportedFrom;
	public InsuranceClaim clickTransportedFrom(String month, String year, String rows, String co1){
		//datePicker(eleTransportedFrom, month, year, rows, co1);

		return this;
	}*/

	/*@FindBy(how=How.ID,using="datepickerTransportedFrom")
	private WebElement eleTransportedFrom;
	@FindBy(how=How.XPATH,using="(//label[text()='Transported from']/following::select[@class='monthselect'])[3]")
	private WebElement elemonthTransportedFrom;
	@FindBy(how=How.XPATH,using="(//label[text()='Transported from']/following::select[@class='yearselect'])[3]")
	private WebElement eleyearTransportedFrom;


	public InsuranceClaim clickandSelectTransportedFrom(String monthTransportedFrom, String yearTransportedFrom){

		selectDate(eleTransportedFrom, "Transported from", monthTransportedFrom, yearTransportedFrom, "1");
		return this;
	}

	@FindBy(how=How.ID,using="datepickerTransportedTo")

	public WebElement eleTransportedTo;
	public InsuranceClaim clickTransportedTo(String month, String year, String rows, String co1){
		//datePicker(eleTransportedTo, month, year, rows, co1);

		return this;
	}*/

	@FindBy(how=How.ID,using="datepickerTransportedTo")
	private WebElement eleTransportedTo;
	@FindBy(how=How.XPATH,using="(//select[@class='monthselect'])[11]")
	private WebElement elemonthTransportedTo;
	@FindBy(how=How.XPATH,using="(//select[@class='yearselect'])[11]")
	private WebElement eleyearTransportedTo;


	public InsuranceClaim clickandSelectTransportedTo(String monthTransportedTo, String yearTransportedTo,String classnameTransportedTo, String rowsTransportedTo, String colTransportedTo){

		datePicker(eleTransportedTo, elemonthTransportedTo, eleyearTransportedTo,classnameTransportedTo, monthTransportedTo, yearTransportedTo, rowsTransportedTo, colTransportedTo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='transportername']")

	public WebElement eleTransporterName;
	public InsuranceClaim typeTransporterName(String dataTransporterName){
		type(eleTransporterName, dataTransporterName);
		return this;
	}

	@FindBy(how=How.XPATH,using="//textarea[@id='transporteraddress']")

	public WebElement eleTransporterAddress;
	public InsuranceClaim typeTransporterAddress(String dataTransporterAddress){
		type(eleTransporterAddress, dataTransporterAddress);
		return this;
	}

	@FindBy(how=How.XPATH,using="//textarea[@id='addressforinspection']")

	public WebElement eleAddressForInspection;
	public InsuranceClaim typeAddressForInspection(String dataAddressForInspection){
		type(eleAddressForInspection, dataAddressForInspection);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='country']")

	private WebElement eleState;
	public InsuranceClaim verifyExactTextState(String dataState) {
		verifyText(eleState,dataState);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//input[@id='country'])[2]")

	private WebElement eleLocationCountry;
	public InsuranceClaim verifyExactTextLocationCountry(String dataLocationCountry) {
		verifyText(eleLocationCountry,dataLocationCountry);
		return this;
	}

	/*@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[7]")

	public WebElement eleLossState;
	public InsuranceClaim selectLossState(String dataLossState){
		selectUsingText(eleLossState, dataLossState);
		return this;
	}*/

	@FindBy(how=How.XPATH,using="//input[@id='strNewState']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleLossState;
	public InsuranceClaim clickLossState(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		/*pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLossState); */
		mouseOverOnElement(eleLossState);
		return this;
	}

	public InsuranceClaim selectUsingTextLossState(String LossState){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LossState+"']"), LossState);
		pause(1);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strNewDistrict']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleLossDistrict;
	public InsuranceClaim clickLossDistrict(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLossDistrict); 
		return this;
	}

	public InsuranceClaim selectUsingTextLossDistrict(String LossDistrict){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LossDistrict+"']"), LossDistrict);
		return this;
	}


	/*	@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[8]")

	private WebElement eleLossDistrict;
	public InsuranceClaim selectLossDistrict(String dataLossDistrict) {
		selectUsingText(eleLossDistrict, dataLossDistrict);
		return this;
	}
	 */
/*
	@FindBy(how=How.XPATH,using="//label[text()='Is Repair Estimate Obtained']/following::input")

	public WebElement eleisRepairedEstimateObtained;
	public InsuranceClaim typeisRepairedEstimateObtained(String dataisRepairedEstimateObtained){
		type(eleisRepairedEstimateObtained, dataisRepairedEstimateObtained);
		return this;
	}*/
	
	@FindBy(how=How.XPATH,using="//input[@id='CIR_Repair_Estimate']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleisRepairedEstimateObtained;
	public InsuranceClaim SelectRepairedEstimateObtained(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(3);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleisRepairedEstimateObtained);*/ 
		mouseOverOnElement(eleisRepairedEstimateObtained);
		return this;
	}

	public InsuranceClaim selectUsingTextRepairedEstimateObtained(String RepairedEstimateObtained){
		pause(3);
		click(locateElement("xpath","(//li[text()='"+RepairedEstimateObtained+"'])[2]"));
		
		/*try {
			selectUsingText(locateElement("xpath","(//li[text()='"+RepairedEstimateObtained+"'])[2]"), RepairedEstimateObtained);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		return this;
	}
	
	

	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[1]")

	public WebElement eleAddNewRecordGrid;
	public InsuranceClaim clickAddNewRecordGrid(){
		//click(eleAddNewRecordGrid);
		//wait.until(ExpectedConditions.visibilityOf(eleAddNewRecordGrid));
		//mouseOverOnElement(eleAddNewRecordGrid);

		((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAddNewRecordGrid);
		mouseOverOnElement(eleAddNewRecordGrid);
		return this;
	}

	/*@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleSNOGrid;
	public InsuranceClaim typeSNOGrid(String dataSNOGrid){
		verifyText(elePSNOGrid, dataSNOGrid);
		return this;
	}*/

	@FindBy(how=How.XPATH,using="//input[@id='strPsno']")

	public WebElement elePSNOGrid;
	public InsuranceClaim typePSNOGrid(String dataPSNOGrid){

		typeAndChoose(elePSNOGrid, dataPSNOGrid);

		//Check mobile number and email is autofetch or not

		/*String text = getText(locateElement("xpath", "//a[text()='Mobile No']/../following::div[3]//tbody//td[4]"));

		System.out.println(text);
		if (text==null) {
			click(locateElement("xpath", "//a[text()='Edit']"));
			//type(locateElement("xpath",""))
		}

		else if(text.isEmpty()==true){
			click(locateElement("xpath", "//a[text()='Edit']"));	
		}else {

			System.out.println("Isn't necessary to Edit mobile number field;Edit button not clicked");

		}*/
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='budetails']")
	
	public List<WebElement> eleSumOFInsured;
	public InsuranceClaim UIValidation(){
		dateAndMoneyUI = new ArrayList<String>();
		for (WebElement sum : eleSumOFInsured) {
			String text = sum.getAttribute("value");
			System.out.println(text);
			dateAndMoneyUI.add(text);
			pause(2);
			
		}
		
		return this;
	
	}
	
	public InsuranceClaim compareDataWithDB() {
		for (String values : dateAndMoneyUI) {

			if(dateAndMoneyDB.contains(values)) {
				System.out.println("DB VALIDATION SUCCESSFULLY");	
			}else {
				System.out.println("DB VALIDATION FAILED");
			}
		}

		return this;

	}
	/*public InsuranceClaim DBValidation(String sql){
		String string = "";
		dateAndMoneyDB = new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb(sql);
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
				string = object.toString();
				 dateAndMoneyDB.add(string);
				 System.out.println(string);
			}
			
		}
			
	return this;
	
	}*/
	
	public InsuranceClaim DBValidation(String query) {
		String string = "";
		dateAndMoneyDB= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb(query);
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
				
				string = object.toString();
				dateAndMoneyDB.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;
	
	}
	
	
	
	
	/*
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public InsuranceClaim getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}*/

	@FindBy(how=How.XPATH,using="//span[text()='Contact Name']/following::td[3]")

	private WebElement eleContactName;
	public InsuranceClaim verifyExactTextCNGrid(String dataCN) {
		verifyText(eleContactName,dataCN);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[text()='Contact Name']/following::div//td[4]")

	private WebElement eleMNGrid;
	public InsuranceClaim verifyExactMobileNo(String dataMN) {
		verifyText(eleMNGrid,dataMN);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[text()='Contact Name']/following::div//td[5]")

	private WebElement eleEmailIDverify;
	public InsuranceClaim verifyExactEmailNo(String dataEMN) {
		verifyText(eleEmailIDverify,dataEMN);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleContactNameGrid;
	public InsuranceClaim typeContactNameGrid(String dataContactNameGrid){
		type(eleContactNameGrid, dataContactNameGrid);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strGContactno']")

	public WebElement eleMobileNumberGrid;
	public InsuranceClaim typeMobileNumberGrid(String dataMobileNumberGrid){
		type(eleMobileNumberGrid, dataMobileNumberGrid);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@id='strGContactemail']")

	public WebElement eleEmailIDGrid;
	public InsuranceClaim typeEmailIDGrid(String dataEmailIDGrid){
		type(eleEmailIDGrid, dataEmailIDGrid);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePaginationLeftAll;
	public InsuranceClaim clickPaginationLeftAll(){
		click(elePaginationLeftAll);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePaginationLeft;
	public InsuranceClaim clickPaginationLeft(){
		click(elePaginationLeft);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePaginationNumber;
	public InsuranceClaim clickPaginationNumber(){
		click(elePaginationNumber);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePaginationRight;
	public InsuranceClaim clickPaginationRight(){
		click(elePaginationRight);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePaginationRightAll;
	public InsuranceClaim clickPaginationRightAll(){
		click(elePaginationRightAll);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()[contains(.,'Submit')]]")

	public WebElement eleSubmit;
	public InsuranceClaim clickSubmit(){
		click(eleSubmit);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()[contains(.,'Submit')]]")

	public WebElement eleSubmitsucess;
	public EditClaimPage clickSubmitsucess(){
		click(eleSubmitsucess);
		return new EditClaimPage();
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleConfirmationMessageAfterSubmit;
	public InsuranceClaim clickConfirmationMessageAfterSubmit(){
		click(eleConfirmationMessageAfterSubmit);
		return this;
	}
	/*@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleTop;
	public InsuranceClaim clickTop(){
		click(eleTop);
		return this;
	}*/
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleIndependentCompanyToolTip;
	public InsuranceClaim clickIndependentCompanyToolTip(){
		click(eleIndependentCompanyToolTip);
		return this;
	}


	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public InsuranceClaim getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public InsuranceClaim closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[2]")

	public WebElement eleAssetAddNewRecordGrid;
	public InsuranceClaim clickAssetAddNewRecordGrid(){

		((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAssetAddNewRecordGrid);
		mouseOverOnElement(eleAssetAddNewRecordGrid);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='select'])[11]")

	public WebElement eleAssertDamageCreate;
	public InsuranceClaim clickAssertDamageCreate(){
		//click(eleCauseOfLoss);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAssertDamageCreate); 
		pause(1);
		mouseOverOnElement(eleAssertDamageCreate);
		//eleAssertDamageCreate.sendKeys(Keys.ENTER);

		return this;
	}


	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	public WebElement eleUpdateGridCreate;
	public InsuranceClaim ClickUpdateGridButtonCreate(){
		click(eleUpdateGridCreate);
		return this;
	}


	@FindBy(how=How.XPATH,using="//a[contains(text(),'Top')]")

	public WebElement eleClickTop;
	public InsuranceClaim ClickTop(){
		click(eleClickTop);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='CIR_Repair_Estimate']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleRepairEstimate;
	public InsuranceClaim clickRepairEstimate(){
		/*WebDriverWait wait=new WebDriverWait(getEventDriver(), 30);
		wait.until(ExpectedConditions.visibilityOf(eleTheftBurglary));*/
		pause(1);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleRepairEstimate); 
		return this;
	}

	public InsuranceClaim selectUsingTexteleRepairEstimate(String RepairEstimate){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+RepairEstimate+"']"), RepairEstimate);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[@id='Edit']")


	private WebElement eleInsurnaceEdit;
	public EditClaimPage clickInsuranceEdit() {
		click(eleInsurnaceEdit);
		return new EditClaimPage();
	}

	@FindBy(how=How.XPATH,using="//button[@id='View']")

	private WebElement eleInsurnaceView;
	public ViewClaimPage clickInsuranceView() {
		click(eleInsurnaceView);
		return new ViewClaimPage();
	}
	
	
	@FindBy(how=How.XPATH,using="//textarea[@id='cargodescription']")

	public WebElement elePLDText;
	public InsuranceClaim typePLD(String dataPLD){
		type(elePLDText, dataPLD);
		return this;
	}



}
