package pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Letter_Of_Requirement extends AbstractPage {
	
	public Letter_Of_Requirement(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Letter Of Requirements']")

	private WebElement eleLOR;
	public Letter_Of_Requirement clickLOR() {
		click(eleLOR);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='Creation']")

	private WebElement eleLORCreate;
	public Letter_Of_Requirement clickLORCreate() {
		click(eleLORCreate);
		pause(3);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleLORCreateFilter;
	public Letter_Of_Requirement clickLORCreateFilter() {
		pause(4);
		click(eleLORCreateFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleLORCreateJobFilter;
	public Letter_Of_Requirement clickLORCreateJobFilter() {
		pause(4);
		click(eleLORCreateJobFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleSurLORCreateClaimFilter;
	public Letter_Of_Requirement clickLORCreateClaimFilter() {
		pause(4);
		click(eleSurLORCreateClaimFilter);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleLORCreateClaimStatusbutton;
	public Letter_Of_Requirement clickLORStatusbutton(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLORCreateClaimStatusbutton); 
		return this;
	}

	public Letter_Of_Requirement selectUsingTexteleLORClaimStatus(String LORCreateClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LORCreateClaimStatus+"']"), LORCreateClaimStatus);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleLORPolicyNo;
	
	public Letter_Of_Requirement typeAndEnterLORPolicyNo(String dataLORPolicyNo){
		pause(1);
		typeAndChoose(eleLORPolicyNo, dataLORPolicyNo); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleLORGetList;
	public Letter_Of_Requirement clickLORGetList() {
		click(eleLORGetList);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleLORClose;
	public Letter_Of_Requirement clickLORClose() {
		click(eleLORClose);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement eleLORxCloseSur;
	public Letter_Of_Requirement clickLORxCloseSur() {
		click(eleLORxCloseSur);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No']/following::u)[1]")
	
	private WebElement eleGridLORfirstvalue;
	public Letter_Of_Requirement clickGridLORfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridLORfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//a[text()='Action']/following::u)[2]")
	
	private WebElement eleGridLORfirstvalueCreate;
	public Letter_Of_Requirement clickGridLORfirstvalueCreate() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridLORfirstvalueCreate);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleLORCreatePaginationRight;
	public Letter_Of_Requirement clickLORCreatePaginationRight() {
		click(eleLORCreatePaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleLORCreatePaginationRightlast;
	public Letter_Of_Requirement clickLORCreatePaginationRightlast() {
		click(eleLORCreatePaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleLORCreatePaginationLeft;
	public Letter_Of_Requirement clickLORCreatePaginationLeft() {
		click(eleLORCreatePaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleLORCreatePaginationLeftlast;
	public Letter_Of_Requirement clickLORCreatePaginationLeftlast() {
		click(eleLORCreatePaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleLORCreatePaginationItemPerPage;
	public Letter_Of_Requirement clickLORCreatePaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLORCreatePaginationItemPerPage); 
		return this;
	}

	public Letter_Of_Requirement selectUsingTexteleLORCreateItemperpage(String LORCreateItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LORCreateItemPerPage+"']"), LORCreateItemPerPage);
		return this;
	}

	
	@FindBy(how=How.XPATH,using="//input[@class='k-textbox']")

	private WebElement eleLORCreatePaginationNumber;
	public Letter_Of_Requirement clickLORCreatePaginationNumber(String datapagenumber) {
		type(eleLORCreatePaginationNumber,datapagenumber);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//button[@id='View']")

	private WebElement eleLORView;
	public LORView clickLORView() {
		click(eleLORView);
		return new LORView();
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']")
	private WebElement eledialogMsg;
	public Letter_Of_Requirement getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']")
	private WebElement eledialogMsg2;
	public Letter_Of_Requirement getdialogMsg2() 
	{
		pause(3);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg2));
		reportStep("The element"+ eledialogMsg2 +"is not visible", "WARNING");
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public Letter_Of_Requirement closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Yes'] ")
	private WebElement eledialogMSgYes;
	public Letter_Of_Requirement closeDialogMsgYes() 
	{

		click(eledialogMSgYes);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//textarea[@id='strrmarks']")

	public WebElement eleLORCreationRemarks;
	
	public Letter_Of_Requirement typeAndEnterLORCreationRemarks(String dataCreationRemarks){
		pause(1);
		type(eleLORCreationRemarks, dataCreationRemarks); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedEmployee']")

	public WebElement eleLORPSNO;
	
	public Letter_Of_Requirement typeAndEnterLORPSNO(String dataLORPSNO){
		pause(2);
		typeAndChoose(eleLORPSNO, dataLORPSNO); 
		pause(3);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//button[@id='btnSubmit11']")
	private WebElement eleLORDocSubmit;
	public Letter_Of_Requirement ClickLORDocSubmit() 
	{
		pause(3);
		click(eleLORDocSubmit);

		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//button[contains(@title,'Click to Upload')])[1]")
	private WebElement eleCheckDOCLOR;
	public Letter_Of_Requirement ClickUploadLORDOC() 
	{
		pause(3);
		click(eleCheckDOCLOR);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//input[@id='tbFileDescription'])[1]")

	public WebElement eleLORFileDesc;
	
	public Letter_Of_Requirement typeLORFileDesc(String dataLORFileDesc){
		pause(3);
		type(eleLORFileDesc, dataLORFileDesc); 
		
		return this;
	}
	
	
	
	
	public Letter_Of_Requirement FileUploadLOR(String filePath) 

	{
		pause(4);
		FileUpload(filePath);
		pause(3);
		return this;

		
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Maximize']")
	private WebElement elemaximizewindow;
	public Letter_Of_Requirement ClickmaximizeButton() 
	{
		pause(2);
		click(elemaximizewindow);

		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//span[text()='Close']")
	private WebElement eleClosewindow;
	public Letter_Of_Requirement ClickCloseWindow() 
	{
		pause(2);
		click(eleClosewindow);

		return this;
	}
	
	
	

}
