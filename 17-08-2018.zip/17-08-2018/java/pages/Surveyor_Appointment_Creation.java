package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Surveyor_Appointment_Creation extends AbstractPage  {


	public Surveyor_Appointment_Creation(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how=How.XPATH,using="//span[text()='Surveyor Appointment']")

	private WebElement eleSurveyorAppointmentMenu;
	public Surveyor_Appointment_Creation clickSurveyorAppointmentMenu() {
		click(eleSurveyorAppointmentMenu);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleSurAppointFilter;
	public Surveyor_Appointment_Creation clickSurAppointFilter() {
		pause(4);
		click(eleSurAppointFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleSurveyor_JobFilter;
	public Surveyor_Appointment_Creation clickSurveyor_AppointmentJobFilter() {
		pause(4);
		click(eleSurveyor_JobFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleSurAppClaimFilter;
	public Surveyor_Appointment_Creation clickSurAppClaimFilter() {
		pause(4);
		click(eleSurAppClaimFilter);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleSurClaimStatusbutton;
	public Surveyor_Appointment_Creation clickSurStatusbutton(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleSurClaimStatusbutton); 
		return this;
	}

	public Surveyor_Appointment_Creation selectUsingTexteleSurClaimStatus(String SurClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+SurClaimStatus+"']"), SurClaimStatus);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleSurPolicyNo;
	public Surveyor_Appointment_Creation typeAndEnterSurPolicyNo(String dataSurPolicyNo){
		pause(1);
		typeAndChoose(eleSurPolicyNo, dataSurPolicyNo); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleSurGetList;
	public Surveyor_Appointment_Creation clickSurGetList() {
		click(eleSurGetList);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleScruClose;
	public Surveyor_Appointment_Creation clickScruClose() {
		click(eleScruClose);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement elexCloseSur;
	public Surveyor_Appointment_Creation clickxCloseSur() {
		click(elexCloseSur);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")
	
	private WebElement eleGridSurfirstvalue;
	public Surveyor_Appointment_Creation clickGridSurfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridSurfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="((//a[text()='Creation / Edit']/following::u))[2]")
	
	private WebElement eleGridSurCreation_Edit;
	public Surveyor_Appointment_Creation clickGridSurCreation_Edit() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridSurCreation_Edit);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleSurAppPaginationRight;
	public Surveyor_Appointment_Creation clickSurAppPaginationRight() {
		click(eleSurAppPaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleSurAppPaginationRightlast;
	public Surveyor_Appointment_Creation clickSurAppPaginationRightlast() {
		click(eleSurAppPaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleSurAppPaginationLeft;
	public Surveyor_Appointment_Creation clickSurAppPaginationLeft() {
		click(eleSurAppPaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleSurAPPPaginationLeftlast;
	public Surveyor_Appointment_Creation clickSurAppPaginationLeftlast() {
		click(eleSurAPPPaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleSurPaginationItemPerPage;
	public Surveyor_Appointment_Creation clickSurPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleSurPaginationItemPerPage); 
		return this;
	}

	public Surveyor_Appointment_Creation selectUsingTexteleSurAPPItemperpage(String SurAppItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+SurAppItemPerPage+"']"), SurAppItemPerPage);
		return this;
	}

	
	@FindBy(how=How.XPATH,using="//button[@id='VisitDate']")

	private WebElement eleSurAPpVisitUpdate;
	public SurveyorVisitUpdate clickSurAppVisitUpdate() {
		click(eleSurAPpVisitUpdate);
		return new SurveyorVisitUpdate();
	}
	
	
	@FindBy(how=How.XPATH,using="//button[@id='VisitDate']")

	private WebElement eleSurAPpView;
	public SurveyorView clickSurAppView() {
		click(eleSurAPpView);
		return new SurveyorView();
	}
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public Surveyor_Appointment_Creation getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='OK'])[2] ")
	private WebElement eledialogMsgClose;
	public Surveyor_Appointment_Creation closeDialogMsg() 
	{

		click(eledialogMsgClose);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='radioButton1']")
	private WebElement eleSurveyorTypeCheckbox;
	public Surveyor_Appointment_Creation SelectCheckCorporateSurveyorType() 
	{
		pause(2);
		click(eleSurveyorTypeCheckbox);
         
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='radioButton2']")
	private WebElement eleSurveyorTypeCheckboxIndividual;
	public Surveyor_Appointment_Creation SelectCheckIndividualSurveyorType() 
	{
		pause(2);
		click(eleSurveyorTypeCheckboxIndividual);

		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='strNameofTheSurveyorCompany']")

	public WebElement eleSurCompanyNameCorporate;
	public Surveyor_Appointment_Creation typeAndEnterSurCompany(String dataSurCorporateCompan){
		pause(2);
		typeAndChoose(eleSurCompanyNameCorporate, dataSurCorporateCompan); 
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='strSurveyorClaimNo']")

	public WebElement eleSurCreationClaimNo;
	public Surveyor_Appointment_Creation typeSurCreationClaimNo(String dataSurCreationClaimNo){
		pause(1);
		typeAndChoose(eleSurCreationClaimNo, dataSurCreationClaimNo); 
		return this;
	}
	
	
	@FindBy(how=How.ID,using="strAppointmentDate")
	private WebElement eleAppointmentDate;
	


	public Surveyor_Appointment_Creation  clickandSelectSurveyorAppointmentDate(String monthSAD, String yearSAD){
		click(eleAppointmentDate);
		 
		
		selectDate3(eleAppointmentDate, "Appointment Date", monthSAD, yearSAD, "1");
		return this;
	}
	
	@FindBy(how=How.ID,using="strClaimDate")
	private WebElement eleClaimDate;
	


	public Surveyor_Appointment_Creation  clickandSelectSurveyorClaimDate(String monthSCD, String yearSCD){
		click(eleClaimDate);
		 
		
		selectDate2(eleClaimDate, "Claim Date ", monthSCD, yearSCD, "5");
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//button[text()='Submit']")
	private WebElement eleSurvCreWinSubmit;
	


	public Surveyor_Appointment_Creation  clickSurCreWindowSubmit(){
		click(eleSurvCreWinSubmit);
		 
		
		
		return this;
	}
	
	
	

}
