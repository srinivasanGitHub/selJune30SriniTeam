package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SurveyorVisitUpdate extends AbstractPage {
	

	public SurveyorVisitUpdate(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")
	
	private WebElement eleGridSurVisitfirstvalue;
	public SurveyorVisitUpdate clickGridSurVisitUpdatefirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridSurVisitfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//u[text()=' Visit Update ']")

	private WebElement eleSurVisitUpdateVisitPaginationRight;
	public SurveyorVisitUpdate clickSurVisitUpdateVisit() {
		pause(5);
		mouseOverOnElement(eleSurVisitUpdateVisitPaginationRight);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleSurVisitUpdateointVisitFilter;
	public SurveyorVisitUpdate clickSurVisitUpdateointVisitFilter() {
		pause(4);
		click(eleSurVisitUpdateointVisitFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleSurveyor_JobFilter;
	public SurveyorVisitUpdate clickSurveyor_AppointmentJobFilter() {
		pause(4);
		click(eleSurveyor_JobFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleSurVisitUpdateVisitFilter;
	public SurveyorVisitUpdate clickSurVisitUpdateVisitFilter() {
		pause(4);
		click(eleSurVisitUpdateVisitFilter);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleSurVisitUpdateVisitPolicyNo;
	public SurveyorVisitUpdate typeAndEnterSurPolicyNo(String dataSurVisitPolicyNo){
		pause(1);
		typeAndChoose(eleSurVisitUpdateVisitPolicyNo, dataSurVisitPolicyNo); 
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleSurVisitGetList;
	public SurveyorVisitUpdate clickSurVisitGetList() {
		click(eleSurVisitGetList);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleSurVisitClose;
	public SurveyorVisitUpdate clickSurVisitClose() {
		click(eleSurVisitClose);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement elexCloseSurVisitUpdate;
	public SurveyorVisitUpdate clickxCloseSurVisit() {
		click(elexCloseSurVisitUpdate);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleSurVisitUpdatePaginationRight;
	public SurveyorVisitUpdate clickSurVisitUpdatePaginationRight() {
		click(eleSurVisitUpdatePaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleSurVisitUpdatePaginationRightlast;
	public SurveyorVisitUpdate clickSurVisitUpdatePaginationRightlast() {
		click(eleSurVisitUpdatePaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleSurVisitUpdatePaginationLeft;
	public SurveyorVisitUpdate clickSurVisitUpdatePaginationLeft() {
		click(eleSurVisitUpdatePaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleSurVisitUpdatePaginationLeftlast;
	public SurveyorVisitUpdate clickSurVisitUpdatePaginationLeftlast() {
		click(eleSurVisitUpdatePaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleSurPaginationItemPerPage;
	public SurveyorVisitUpdate clickSurPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleSurPaginationItemPerPage); 
		return this;
	}

	public SurveyorVisitUpdate selectUsingTexteleSurVisitUpdateItemperpage(String SurVisitUpdateItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+SurVisitUpdateItemPerPage+"']"), SurVisitUpdateItemPerPage);
		return this;
	}

	
	
}
