package pages;

import org.openqa.selenium.WebElement;

import base.WdMethods;
public class AbstractPage extends WdMethods{
	
	



}
