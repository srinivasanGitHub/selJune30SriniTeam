package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LORView extends AbstractPage {

	public LORView() {
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleLORViewFilter;
	public LORView clickLORViewFilter() {
		pause(4);
		click(eleLORViewFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleLORViewJobFilter;
	public LORView clickLORViewJobFilter() {
		pause(4);
		click(eleLORViewJobFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleSurLORViewClaimFilter;
	public LORView clickLORViewClaimFilter() {
		pause(4);
		click(eleSurLORViewClaimFilter);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleLORViewClaimStatusbutton;
	public LORView clickLORViewStatusbutton(){

		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLORViewClaimStatusbutton); 
		return this;
	}

	public LORView selectUsingTexteleLORViewClaimStatus(String LORViewClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LORViewClaimStatus+"']"), LORViewClaimStatus);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleLORViewPolicyNo;

	public LORView typeAndEnterLORViewPolicyNo(String dataLORViewPolicyNo){
		pause(1);
		typeAndChoose(eleLORViewPolicyNo, dataLORViewPolicyNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleLORViewGetList;
	public LORView clickLORViewGetList() {
		click(eleLORViewGetList);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleLORViewClose;
	public LORView clickLORViewClose() {
		click(eleLORViewClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement eleLORViewxCloseSur;
	public LORView clickLORViewxCloseSur() {
		click(eleLORViewxCloseSur);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No']/following::u)[1]")

	private WebElement eleGridLORViewfirstvalue;
	public LORView clickGridLORViewfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridLORViewfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//a[text()='Action']/following::u)[2]")
	
	private WebElement eleGridLORfirstvalueView;
	public LORView clickGridLORfirstvalueView() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridLORfirstvalueView);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleLORViewPaginationRight;
	public LORView clickLORViewPaginationRight() {
		click(eleLORViewPaginationRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleLORViewPaginationRightlast;
	public LORView clickLORViewPaginationRightlast() {
		click(eleLORViewPaginationRightlast);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleLORViewPaginationLeft;
	public LORView clickLORViewPaginationLeft() {
		click(eleLORViewPaginationLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleLORViewPaginationLeftlast;
	public LORView clickLORViewPaginationLeftlast() {
		click(eleLORViewPaginationLeftlast);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleLORViewPaginationItemPerPage;
	public LORView clickLORViewPaginationItemPerPage(){
		
		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleLORViewPaginationItemPerPage); 
		return this;
	}

	public LORView selectUsingTexteleLORViewItemperpage(String LORViewItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+LORViewItemPerPage+"']"), LORViewItemPerPage);
		return this;
	}

	
	@FindBy(how=How.XPATH,using="//input[@class='k-textbox']")

	private WebElement eleLORViewPaginationNumber;
	public LORView clickLORViewPaginationNumber(String datapagenumber) {
		type(eleLORViewPaginationNumber,datapagenumber);
		return this;
	}
	
	
	

}
