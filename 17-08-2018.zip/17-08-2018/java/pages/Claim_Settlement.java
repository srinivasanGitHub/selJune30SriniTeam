package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Claim_Settlement extends AbstractPage {


	public Claim_Settlement() {
		PageFactory.initElements(getEventDriver(), this);
	}


	@FindBy(how=How.XPATH,using="//span[text()='Claim Settlement']")

	public WebElement eleClaimSettlementMenu;
	public Claim_Settlement clickClaimSettlementMenu() {
		pause(4);
		click(eleClaimSettlementMenu);
		return this;
	}



	@FindBy(how=How.XPATH,using="//button[@title='Click here to view filter...!']")

	public WebElement eleClaimSettlementCreationFilter;
	public Claim_Settlement clickClaimSettlementCreationFilter() {
		pause(4);
		click(eleClaimSettlementCreationFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedJobCode']")

	public WebElement eleClaimSettlementCreationJobFilter;
	public Claim_Settlement clickClaimSettlementJobFilter() {
		pause(4);
		click(eleClaimSettlementCreationJobFilter);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Selectedclaimno']")

	public WebElement eleClaimSettlementCreationClaimFilter;
	public Claim_Settlement clickClaimSettlementCreationClaimFilter() {
		pause(4);
		click(eleClaimSettlementCreationClaimFilter);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='strClaimStatus']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleClaimSettlementCreationClaimStatusbutton;
	public Claim_Settlement clickClaimSettlementStatusbutton(){

		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleClaimSettlementCreationClaimStatusbutton); 
		return this;
	}

	public Claim_Settlement selectUsingTextClaim(String ClaimSettlementCreationClaimStatus){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+ClaimSettlementCreationClaimStatus+"']"), ClaimSettlementCreationClaimStatus);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='SelectedPolicyNo']")

	public WebElement eleClaimSettlementCreationPolicyNo;

	public Claim_Settlement typeAndEntereleClaimSettlementCreationPolicyNo(String dataClaimSettlementPolicyNo){
		pause(1);
		typeAndChoose(eleClaimSettlementCreationPolicyNo, dataClaimSettlementPolicyNo); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Get List']")

	private WebElement eleClaimSettlementGetList;
	public Claim_Settlement clickClaimSettleGetList() {
		click(eleClaimSettlementGetList);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Close']")

	private WebElement eleClaimSettlementClose;
	public Claim_Settlement clicClaimSettlecreaClose() {
		click(eleClaimSettlementClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//button[text()='�'])[2]")

	private WebElement eleClaimSettlementxCloseSur;
	public Claim_Settlement clickClaimSettlementxCloseSur() {
		click(eleClaimSettlementxCloseSur);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[@id='Creation']")

	private WebElement eleClaimSettlementCreationbutton;
	public Claim_Settlement clickClaimSettlementCreationbutton() {
		click(eleClaimSettlementCreationbutton);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Claim Request No.']/following::u)[1]")

	private WebElement eleGridClaimSettlementCreationfirstvalue;
	public Claim_Settlement clickGridClaimSettlementCreationfirstvalue() {
		//click(eleGridEdit);
		pause(5);
		mouseOverOnElement(eleGridClaimSettlementCreationfirstvalue);
		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
			js.executeScript("arguments[0].click();",eleGridEdit); */
		return this;
	}


	@FindBy(how=How.XPATH,using="//a[text()='Action']/following::b")

	private WebElement eleClaimSettlementCreActionGridFirst;
	public Claim_Settlement clickClaimSettlementCreaActionGridFirst() {
		click(eleClaimSettlementCreActionGridFirst);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Action']/following::b)[2]")

	private WebElement eleClaimSettlementClosActionGridFirst;
	public Claim_Settlement clickClaimSettlementClosActionGridFirst() {
		click(eleClaimSettlementClosActionGridFirst);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//a[@class='RedirectInsuranceClosure'])[2]")

	private WebElement eleClaimSettlementClosure;
	public Claim_Settlement clickeleClaimSettlementClosure() {
		click(eleClaimSettlementClosure);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//textarea[@id='strClosureRemarks']")

	private WebElement eleClosureRemarks;
	public Claim_Settlement typeClosureRemarks(String closureRemarks) {
		type(eleClosureRemarks,closureRemarks);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	private WebElement eleClaimSettlementPaginationRight;
	public Claim_Settlement clickClaimSettlementPaginationRight() {
		click(eleClaimSettlementPaginationRight);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	private WebElement eleClaimSettlementPaginationRightlast;
	public Claim_Settlement clickClaimSettlementPaginationRightlast() {
		click(eleClaimSettlementPaginationRightlast);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	private WebElement eleClaimSettlementPaginationLeft;
	public Claim_Settlement clickClaimSettlementPaginationLeft() {
		click(eleClaimSettlementPaginationLeft);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	private WebElement eleClaimSettlementPaginationLeftlast;
	public Claim_Settlement clickClaimSettlementPaginationLeftlast() {
		click(eleClaimSettlementPaginationLeftlast);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]")

	public WebElement eleClaim_SettlementPerPaginationItemPerPage;
	public Claim_Settlement clickeleClaim_SettlementPaginationItemPerPage(){

		pause(2);
		JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleClaim_SettlementPerPaginationItemPerPage); 
		return this;
	}

	public Claim_Settlement selectUsingTexteleClaim_Settlement(String Claim_SettlementItemPerPage){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+Claim_SettlementItemPerPage+"']"), Claim_SettlementItemPerPage);
		return this;
	}
	
	

	@FindBy(how=How.XPATH,using="//button[@id='Edit']")

	private WebElement eleClaimSettlementEdit;
	public Claim_SettlementEdit clickClaimSettlementEdit() {
		click(eleClaimSettlementEdit);
		return new Claim_SettlementEdit() ;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='View']")

	private WebElement eleClaimSettlementView;
	public Claim_SettlementView clickClaimSettlementView() {
		click(eleClaimSettlementEdit);
		return new Claim_SettlementView();
	}

	@FindBy(how=How.LINK_TEXT,using="Add new record")
	private WebElement eleAddNewRecord;
	public Claim_Settlement clickAddNewRecord()
	{
		pause(2);
		click(eleAddNewRecord);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//span[@class='k-select']/span)[3]")

	private WebElement eleSettlementType;
	public Claim_Settlement clickandSelectSettlementType() {
		click(eleSettlementType);
		return this;
	}

	public Claim_Settlement selectUsingTextSettlementType(String settleymentType){
		pause(2);
		selectUsingText(locateElement("xpath","//li[text()='"+settleymentType+"']"), settleymentType);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='OrderDescription']")

	private WebElement eleReceiptNum;
	public Claim_Settlement typeReceiptNum(String ReceiptNum) {
		pause(2);
		typeandEnter(eleReceiptNum, ReceiptNum);
		return this;
	}

	public Claim_Settlement selectReceiptdate(String ReceiptDate) {

		selectDateFromKendo(ReceiptDate);

		return this;
	}



	@FindBy(how=How.ID,using="settlementSubmit")

	private WebElement elebtnSubmit;
	public Claim_Settlement clickSettlementSubmit() {
		click(elebtnSubmit);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	private WebElement elebtnUpdate;
	public Claim_Settlement clickUpdate() {
		click(elebtnUpdate);
		return this;
	}

	@FindBy(how=How.CSS,using=".k-icon.k-i-calendar")

	private WebElement eleReceiptCalender;
	public  Claim_Settlement clickReceiptCalender()
	{
		pause(2);
		click(eleReceiptCalender);
		pause(2);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='RecieptDate']")
	private WebElement eleRecptCalender;
	public Claim_Settlement typeReceiptDate(String receiptDate)
	{
		typeandEnter(eleRecptCalender, receiptDate);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='bankDetails']")
	private WebElement elebankDetails;
	public Claim_Settlement typeBankDetails(String bankDetails)
	{
		typeandEnter(elebankDetails, bankDetails);
		return this;
	}



	@FindBy(how=How.XPATH,using="//a[@class='settelementAmountWindow']")
	private WebElement elesettlementAmt;
	public Claim_Settlement clickSettlementAmount()
	{
		click(elesettlementAmt);
		pause(3);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[2]")

	public WebElement eleAssetAddNewRecordGrid;
	public Claim_Settlement clickAssetAddNewRecordGrid(){

		//((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAssetAddNewRecordGrid);
		mouseOverOnElement(eleAssetAddNewRecordGrid);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='select'])[1]")

	public WebElement eleAssetDamageCreate;
	public Claim_Settlement clickAssetType(){

		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAssetDamageCreate); */
		pause(1);
		mouseOverOnElement(eleAssetDamageCreate);


		return this;
	}



	@FindBy(how=How.XPATH,using="//ul[@id='asset_type_listbox']//li[2]")

	public WebElement eleAssetTypeValue;
	public Claim_Settlement clickAssetTypeValue(){

		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAssetDamageCreate); */
		pause(1);
		mouseOverOnElement(eleAssetTypeValue);



		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ScAmount']")
	public WebElement elesettlementAmount;
	@FindBy(how=How.XPATH,using="//input[@id='GAmount']")
	public WebElement eleGrossAmount;

	public Claim_Settlement typeAmount(String settlementType,String settlementAmt,String grossAmt)
	{
		if(settlementType.equalsIgnoreCase("Full"))
		{
			pause(1);
			type(elesettlementAmount, settlementAmt);
			type(eleGrossAmount, grossAmt);

		}
		else
		{	
			pause(1);
			type(elesettlementAmount, settlementAmt);
		}
		
		return this;
	}
	
	
		
	@FindBy(how=How.XPATH,using="(//span[@class='k-numeric-wrap k-state-default'])[1]")

	public WebElement eleAssetAmount;
	@FindBy(how=How.XPATH,using="//span/input[@id='amount']")
	public WebElement eleAssetAmountvalue;

	@FindBy(how=How.XPATH,using="(//span[@class='k-icon k-i-arrow-n'])[1]")
	public WebElement eleAssetAmountArrow;

	public Claim_Settlement typeAssetAmount(String AssetAmount){

		click(eleAssetAmount);
		eleAssetAmount.sendKeys(Keys.BACK_SPACE);
		pause(1);
		type(eleAssetAmountvalue, AssetAmount);

		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='CSA_Gross_assessed_loss']/preceding-sibling::input")
	public WebElement eleAssetGrossAssessAmt;

	@FindBy(how=How.XPATH,using="//input[@id='CSA_Gross_assessed_loss']")
	public WebElement eleAssetGrossAssessAmtValue;

	public Claim_Settlement typeAssetGrossassessedAmt(String grossAmount){
		pause(2);
		JavascriptExecutor js1 = (JavascriptExecutor) getDriver();
		js1.executeScript("arguments[0].click();",eleAssetGrossAssessAmt);
		pause(5);
		/*eleAssetGrossAssessAmt.clear();
		eleAssetGrossAssessAmt.sendKeys(Keys.DELETE);*/
		//eleAssetGrossAssessAmt.sendKeys(Keys.BACK_SPACE);
		type(eleAssetGrossAssessAmtValue, grossAmount);
		return this;
	}
	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	public WebElement eleAssetUpdateBtn;
	public Claim_Settlement clickAssetUpdateBtn(){
		click(eleAssetUpdateBtn);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='Remarks']")

	public WebElement eleReceiptDetailsRemarks;
	public Claim_Settlement typeReceiptDetailsRemarks(String remarksData){
		type(eleReceiptDetailsRemarks, remarksData);
		return this;
	}

	
	
	
	@FindBy(how=How.XPATH,using="//label[@id='PartialSettled']")
	public WebElement elePartial;
	@FindBy(how=How.XPATH,using="//label[@id='FullSettled']")
	public WebElement elefull;
	
	@FindBy(how=How.XPATH,using="//button[text()='Proceed']")
	public WebElement eleSettlAmtProceedWithoutAsset;
	@FindBy(how=How.XPATH,using="(//button[text()='Proceed'])[2]")
	public WebElement eleSettlAmtProceedBtn;
	
	public Claim_Settlement clickSettlAmtProceed(){
		if(elefull.isDisplayed() || elePartial.isDisplayed())
		{
			click(eleSettlAmtProceedWithoutAsset);
		}
		else
		{
			click(eleSettlAmtProceedBtn);
		}
		return this;
	}




	@FindBy(how=How.XPATH,using="(//a[text()='Edit'])[1]")

	public WebElement eleReceiptDetailtEditBtn;
	public Claim_Settlement clickReceiptDetailEditBtn(){
		click(eleReceiptDetailtEditBtn);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	public WebElement eleReceiptDetailtUpdateBtn;
	public Claim_Settlement clickReceiptDetailUpdateBtn(){
		click(eleReceiptDetailtUpdateBtn);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//a[text()='Delete'])[1]")

	public WebElement eleReceiptDetailtDeleteBtn;
	public Claim_Settlement clickReceiptDetailDeleteBtn(){
		click(eleReceiptDetailtDeleteBtn);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[@class='settelementCreationWindow']")
	private WebElement eleDeductionAmt;
	public Claim_Settlement clickDeductionAmt()
	{
		click(eleDeductionAmt);
		pause(3);
		return this;
	}



	@FindBy(how=How.XPATH,using="(//a[text()='Add new record'])[3]")

	public WebElement eleDeductionAddNewRecord;
	public Claim_Settlement clickDeductionAddNewRecord(){

		//((JavascriptExecutor) getEventDriver()).executeScript("arguments[0].scrollIntoView(true);", eleAssetAddNewRecordGrid);
		mouseOverOnElement(eleDeductionAddNewRecord);
		return this;
	}



	
	
	@FindBy(how=How.XPATH,using="//ul[@id='deduction_type_listbox']//li[2]")

	public WebElement eleDeductionTypeValue;
	public Claim_Settlement clickDeductionTypeValue(){

		/*JavascriptExecutor js = (JavascriptExecutor) getDriver();
		js.executeScript("arguments[0].click();",eleAssetDamageCreate); */
		pause(1);
		mouseOverOnElement(eleDeductionTypeValue);



		return this;
	}
	
	@FindBy(how=How.XPATH,using=" ")
	public WebElement eleDeductionAmount;

	public Claim_Settlement typeDeductionAmount(String DeductionAmt){

		click(eleDeductionAmount);
		eleDeductionAmount.sendKeys(Keys.BACK_SPACE);
		pause(1);
		type(eleDeductionAmount, DeductionAmt);

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Remarks']")

	public WebElement eleDeductionRemarks;
	public Claim_Settlement typeDeductionRemarks(String deductioRemarks){
		type(eleDeductionRemarks, deductioRemarks);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Update']")

	public WebElement eleDeductionUpdateBtn;
	public Claim_Settlement clickDeductionUpdateBtn(){
		click(eleDeductionUpdateBtn);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Cancel']")

	public WebElement eleDeductionCancelBtn;
	public Claim_Settlement clickDeductionCancelBtn(){
		click(eleDeductionCancelBtn);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='Proceed'])[3]")

	public WebElement eleDeductionAmtProceedBtn;
	public Claim_Settlement clickDeductionAmtProceed(){
		click(eleDeductionAmtProceedBtn);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//div[@class='bootbox-body']/div")
	private WebElement eledialogMsg;
	public Claim_Settlement getdialogMsg() 
	{
		pause(5);
		//dialogMessage = getText(eledialogMsg);		
		System.out.println("Dialog message:"+ getText(eledialogMsg));
		if (getText(eledialogMsg)!="")
		{
			reportStep("The element"+ eledialogMsg +"is  visible", "INFO");
		}
		else
		{
			reportStep("The element"+ eledialogMsg +"is not visible", "WARNING");
		}

		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='OK'] ")
	private WebElement eledialogMsgClose;
	public Claim_Settlement closeDialogMsg() 
	{	
		click(eledialogMsgClose);
		return this;
	}
	




}


/*Kendo Calender

		@FindBy(how=How.XPATH,using="//div[@id='RecieptDate_dateview']/div[@data-role='calendar']//a[2]")

	     public WebElement eleMonthYear;

	     @FindBy(how=How.XPATH,using="//div[@id='RecieptDate_dateview']/div[@data-role='calendar']/table//td")

	     private List<WebElement> eleYears;

	     @FindBy(how=How.XPATH,using="//div[@id='RecieptDate_dateview']/div[@data-role='calendar']//a[1]")
	     private WebElement eleArrowLeft;


	     @FindBy(how=How.XPATH,using="//div[@id='RecieptDate_dateview']/div[@data-role='calendar']//a[3]")
	     private WebElement eleArrowRight;

	     public List<Integer> years;


	     public Claim_Settlement addYears()
	     {
	           years=new ArrayList<>();
	           for(int i=0;i<eleYears.size();i++)
	           {
	                years.add(Integer.parseInt(eleYears.get(i).getText()));
	           }

	           return this;
	     }

	     public String getHalfMonth(String month)
	     {
	           String halfMonth="";

	           try {
				for(int i=0;i<3;i++)
				   {
				        halfMonth=halfMonth+month.charAt(i);
				        System.out.println("The splitted month is "+halfMonth);
				   }
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.err.println(e);
			}
	           System.out.println("The splitted month is "+halfMonth);
	           return halfMonth;
	     }

	     public Claim_Settlement selectReceiptDate(String year,String month,String date){

	           String monthYear=getText(eleMonthYear);
	           System.out.println("//a[contains(@title,'"+month+" "+date+"')]");
	           String halfMonth=getHalfMonth(month);

	           int integerYear=Integer.parseInt(year);

	           if(integerYear<1900 || integerYear>2099) {
	                System.out.println("Please enter valid year");
	           }
	           else if(monthYear.contains(year))
	           {
	                if(monthYear.contains(month))
	                     click(locateElement("xpath", "//div[@id='RecieptDate_dateview']//a[contains(@title,'"+month+" "+date+"')]"));
	                else
	                {
	                     //Tuesday, July 24, 2018//a[contains(@title,'July 28')]
	                     click(eleMonthYear);
	                     click(locateElement("xpath", "//a[text()='"+halfMonth+"']"));
	                     click(locateElement("xpath", "//div[@id='RecieptDate_dateview']//a[contains(@title,'"+month+" "+date+"')]"));
	                }

	           }
	           else 
	           {
	                click(eleMonthYear);
	                click(eleMonthYear);
	                while(eleArrowLeft.getAttribute("aria-disabled").equals("false")||eleArrowRight.getAttribute("aria-disabled").equals("false"))
	                {
	                     addYears();
	                     if(years.contains(Integer.parseInt(year))) {
	                                click(locateElement("xpath", "//a[text()='"+year+"']"));
	                                click(locateElement("xpath", "//a[text()='"+halfMonth+"']"));
	                                click(locateElement("xpath", "//div[@id='RecieptDate_dateview']//a[contains(@title,'"+month+" "+date+"')]"));
	                                break;
	                     }

	                     else if(Integer.parseInt(year)<years.get(0))
	                           click(eleArrowLeft);
	                     else if(Integer.parseInt(year)>years.get(years.size()-1))
	                           click(eleArrowRight);

	           }

	           }

	           return this;
	     }

		JavascriptExecutor js1 = (JavascriptExecutor) getDriver();
		js1.executeScript("arguments[0]s.click();",eleAssertAmount);
		pause(3);*/

//eleAssertAmount.sendKeys(Keys.DELETE);;
//type(eleAssertAmountvalue,assertAmount);
//eleAssertAmount.sendKeys(Keys.DELETE);
//eleAssertAmount.sendKeys(Keys.BACK_SPACE);
//type(eleAssertAmount,assertAmount);
/*Actions builder=new Actions(getEventDriver());
		pause(3);
		builder.moveToElement(eleAssertAmountArrow).sendKeys(Keys.ESCAPE);*/

//return this;
//mouseOverOnElement(eleAssertAmount);
/*eleAssertAmount.clear();
				eleAssertAmount.sendKeys("100");*/
/*WebDriverWait wait= new WebDriverWait(getEventDriver(), 30);
				wait.until(ExpectedConditions.elementToBeClickable(eleAssertAmount));
				WebDriverWait wait1= new WebDriverWait(getEventDriver(), 30);
				wait1.until(ExpectedConditions.elementToBeClickable(eleAssertAmountvalue));

				JavascriptExecutor js = (JavascriptExecutor) getDriver();
				js.executeScript("arguments[0].click();",eleAssertAmount);*/
