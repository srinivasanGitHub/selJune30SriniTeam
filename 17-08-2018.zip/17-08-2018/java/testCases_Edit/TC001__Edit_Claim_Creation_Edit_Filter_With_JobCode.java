package testCases_Edit;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001__Edit_Claim_Creation_Edit_Filter_With_JobCode extends PreAndPost{

	@BeforeClass
	public void setValues() {
		//browserName="internet explorer";
		browserName="chrome";
		testCaseName="Edit Policy Details ";
		testDescription="Edit Policy Details in Insurance Claim ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Edit - Filter_ClaimNo -Jobcode";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String dataeleEditJobCodeJobCode)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceEdit()
		.clickClaimFilter()
		.typeAndEnterJobCode(dataeleEditJobCodeJobCode)
		.clickGetList();
		
		
		
		
		
		




	}

}
