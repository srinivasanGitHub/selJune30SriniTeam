package testCases_Edit;

import org.sikuli.script.SikuliException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001__Edit_Claim_Creation extends PreAndPost{

	@BeforeClass
	public void setValues() {
		//browserName="internet explorer";
		browserName="chrome";
		testCaseName="Edit Policy Details ";
		testDescription="Edit Policy Details in Insurance Claim ";
		category="Functionlity";
		dataSource="Excel";
		dataSheetName="TC001__Edit";
		authors="Ramki";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String dataEditPolicyNumber
			,String EditCauseOfLoss,String dataEditOccuranceDetails,String EditTheftBurglary,String dataEditFIRNumber,String monthFIR, String yearFIR,String className2,String rowsFIR,String co1FIR,
			String dataOccurenceEnroot,String dataPropertyLostDamaged1,String dataPropertyLostDamaged2,String EditlocationLossState ,String EditlocationLossDistrict, String dataEditExcessAmount ,String dataEditEstimateValue,
			String dataPSNOGrid, String dataMobileNo,String dataEmailID,String dataPSNOGrid1)
					throws SikuliException {
		new LoginPage()

		.enterUserName(uName)
		.enterPassword(pwd)
		.clicklogin()
		.clickInsuranceClaimMenu()
		.clickInsuranceEdit()
		.clickGridEdit()
		.clickGridEdit()
		.typeAndChooseEditPolicyNumber(dataEditPolicyNumber)
		.clickEditCauseOfLoss()
		.selectUsingTextEditCauseOfLoss(EditCauseOfLoss)
		.typeEditOccuranceDetails(dataEditOccuranceDetails)
		.clickEditTheftBurglary()
		.selectUsingTextEditTheftBurglary(EditTheftBurglary)
		.typeEditFIRNumber(dataEditFIRNumber)
		.clickEditFIRDate(monthFIR, yearFIR, className2, rowsFIR, co1FIR)
		.selectUsingTextEditOccurenceEnroot(dataOccurenceEnroot)
		.clickEditPropertyLostDamaged()
		.selectUsingTextEditPropertyLostDamaged(dataPropertyLostDamaged1, dataPropertyLostDamaged2)
		//.clickEditlocationLossState()
		//.selectUsingTextEditlocationLossState(EditlocationLossState)
		//.clickEditlocationLossDistrict()
		//.selectUsingTextEditlocationLossDistrict(EditlocationLossDistrict)
		.typeEditExcessAmount(dataEditExcessAmount)
		.typeEditEstimateAmount(dataEditEstimateValue)
		//.clickTypeOfLoss()
		.clickAddNewRecordGrid()
		.typeEditPSNOGrid(dataPSNOGrid)
		.ClickEditGridButton()
		.TypeGridtMobileNo(dataMobileNo)
		.TypeGridEmailID(dataEmailID)
		.ClickUpdateGridButton()
		.clickAddNewRecordGrid()
		.typeEditPSNOGrid(dataPSNOGrid1)
		.clickAssetAddNewRecordGrid()
		/*.clickAssertDamage()
		.ClickUpdateGridButton()*/
		.clickEditSubmit();
		
		
		
		




	}

}
